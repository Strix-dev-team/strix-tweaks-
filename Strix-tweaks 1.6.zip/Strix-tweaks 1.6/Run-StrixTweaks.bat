@echo off
title Strix Tweaks 1.6
rem  No arguments  -> opens the GUI (asks for Administrator).
rem  With arguments -> unattended mode, e.g.  Run-StrixTweaks.bat -Preset Mid     (run from an elevated prompt)
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0StrixTweaks.ps1" %*
exit /b %errorlevel%
