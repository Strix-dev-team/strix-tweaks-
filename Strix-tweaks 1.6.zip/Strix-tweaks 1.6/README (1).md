# Strix Tweaks 1.6

Windows 11 performance / latency tweaking panel. 99 tweaks across GPU, CPU, SSD/HDD, RAM, power, Wi-Fi/network, audio, services and privacy,
with presets (High-End, Mid-Range, Low-End, Menace), per-game profiles, and a one-click revert that restores your exact original values.

## GUI
Double-click `Run-StrixTweaks.bat` (keep it next to `StrixTweaks.ps1`). It asks for Administrator.

## Unattended / CLI mode (Winget, AME, post-install scripts)
Run from an **elevated** prompt. No window is shown.

```powershell
powershell -ExecutionPolicy Bypass -File StrixTweaks.ps1 -Preset High
powershell -ExecutionPolicy Bypass -File StrixTweaks.ps1 -Preset Mid
powershell -ExecutionPolicy Bypass -File StrixTweaks.ps1 -Preset Low -Laptop -NoRestorePoint
powershell -ExecutionPolicy Bypass -File StrixTweaks.ps1 -Preset Menace -AcceptRisk
powershell -ExecutionPolicy Bypass -File StrixTweaks.ps1 -ProfilePath .\my-setup.strix
powershell -ExecutionPolicy Bypass -File StrixTweaks.ps1 -Revert
powershell -ExecutionPolicy Bypass -File StrixTweaks.ps1 -List
```

| Switch | Meaning |
|---|---|
| `-Preset High\|Mid\|Low\|Menace` | Apply a preset |
| `-ProfilePath file.strix` | Apply a profile exported from the GUI |
| `-Revert` | Undo everything Strix applied (tweaks + game profiles) |
| `-List` | Print every tweak id, risk and preset |
| `-Laptop` / `-Desktop` | Override laptop auto-detection (laptop mode skips battery-hungry tweaks) |
| `-NoRestorePoint` | Skip the Windows restore point |
| `-AllowHybridRisk` | Turn off the Optimus/MUX safety (allows Disable-MPO on hybrid-graphics laptops) |
| `-AcceptRisk` | Required for Menace, or any profile containing tweaks marked Risky |

Exit codes: `0` OK, `3010` OK but reboot required, `2` refused (risky tweaks without `-AcceptRisk`, or bad profile), `5` not elevated.
Per-user (HKCU) tweaks apply to the account running the script, so don't run it as SYSTEM for a user's PC.

Undo data lives in `C:\ProgramData\StrixTweaks\undo`, the log in `C:\ProgramData\StrixTweaks\strix.log`.
