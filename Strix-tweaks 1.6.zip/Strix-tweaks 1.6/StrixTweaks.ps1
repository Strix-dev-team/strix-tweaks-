#Requires -Version 5.1
<#
  STRIX TWEAKS 1.6  -  Windows 11 performance / latency tweaking panel (GPU, CPU, SSD/HDD, RAM, power, Wi-Fi/latency)
  - Presets: High-End, Mid-Range, Low-End, MENACE MODE (everything)
  - Every tweak snapshots the ORIGINAL value first, so Revert restores your exact previous state
  - Restore point is created before anything is applied
  - Per-game recommended settings + per-game profile (GPU preference, fullscreen-optimization, CPU priority)
  Run via Run-StrixTweaks.bat (or right-click > Run with PowerShell). Needs Administrator.

  UNATTENDED / CLI MODE (no GUI, for scripts, Winget, AME, post-install deployment):
    StrixTweaks.ps1 -Preset High|Mid|Low|Menace [-Laptop|-Desktop] [-NoRestorePoint] [-AllowHybridRisk] [-AcceptRisk]
    StrixTweaks.ps1 -ProfilePath my-setup.strix [-AcceptRisk]
    StrixTweaks.ps1 -Revert          (undo everything Strix applied)
    StrixTweaks.ps1 -List            (print every tweak)
  Exit codes: 0 = OK, 3010 = OK but reboot required, 2 = refused (risky tweaks without -AcceptRisk / bad profile), 5 = not elevated.
#>

[CmdletBinding()]
param(
    [ValidateSet('High', 'Mid', 'Low', 'Menace')][string]$Preset,
    [string]$ProfilePath,
    [switch]$Revert,
    [switch]$List,
    [switch]$Laptop,
    [switch]$Desktop,
    [switch]$NoRestorePoint,
    [switch]$AllowHybridRisk,
    [switch]$AcceptRisk
)

$ErrorActionPreference = 'Continue'
$script:Version = '1.6'
$script:Cli = [bool]($Preset -or $ProfilePath -or $Revert -or $List)

# ------------------------------------------------------------------ elevation
$wid = [Security.Principal.WindowsIdentity]::GetCurrent()
$wp  = New-Object Security.Principal.WindowsPrincipal($wid)
if (-not $wp.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    if ($script:Cli) { [Console]::Error.WriteLine('Strix Tweaks: unattended mode needs an elevated (Administrator) session.'); exit 5 }
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -STA -File `"$PSCommandPath`""
    exit
}

if (-not $script:Cli) { Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms }

if (-not ('StrixTweak' -as [type])) {
    Add-Type -TypeDefinition @'
using System.ComponentModel;
public class StrixTweak : INotifyPropertyChanged {
    public event PropertyChangedEventHandler PropertyChanged;
    void N(string p) { if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(p)); }
    bool _sel; string _status = "";
    public bool Selected { get { return _sel; } set { _sel = value; N("Selected"); } }
    public string Status { get { return _status; } set { _status = value; N("Status"); } }
    public string Id { get; set; }
    public string Category { get; set; }
    public string Name { get; set; }
    public string Desc { get; set; }
    public string Risk { get; set; }
    public int Tier { get; set; }
    public string Level { get; set; }
    public bool NoLaptop { get; set; }
    public bool Reboot { get; set; }
    public object Apply { get; set; }
}
'@
}

if (-not $script:Cli -and -not ('StrixMem' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class StrixMem {
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    struct TokPriv { public int Count; public long Luid; public int Attr; }
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool OpenProcessToken(IntPtr h, int acc, out IntPtr tok);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool LookupPrivilegeValue(string host, string name, out long luid);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool AdjustTokenPrivileges(IntPtr tok, bool disAll, ref TokPriv newst, int len, IntPtr prev, IntPtr relen);
    [DllImport("ntdll.dll")] static extern uint NtSetSystemInformation(int cls, IntPtr info, int len);
    [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
    public static bool Priv() {
        IntPtr tok;
        if (!OpenProcessToken(GetCurrentProcess(), 0x28, out tok)) return false;
        TokPriv tp = new TokPriv(); tp.Count = 1; tp.Attr = 2;
        long luid;
        if (!LookupPrivilegeValue(null, "SeProfileSingleProcessPrivilege", out luid)) return false;
        tp.Luid = luid;
        return AdjustTokenPrivileges(tok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
    }
    public static uint Cmd(int c) {
        IntPtr p = Marshal.AllocHGlobal(4);
        Marshal.WriteInt32(p, c);
        uint r = NtSetSystemInformation(80, p, 4);
        Marshal.FreeHGlobal(p);
        return r;
    }
}
'@
}

if (-not $script:Cli -and -not ('StrixTimer' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
public class StrixTimer {
    [DllImport("ntdll.dll")] static extern int NtQueryTimerResolution(out uint min, out uint max, out uint cur);
    [DllImport("ntdll.dll")] static extern int NtSetTimerResolution(uint desired, bool set, out uint actual);
    [DllImport("winmm.dll")] static extern uint timeBeginPeriod(uint ms);
    [DllImport("winmm.dll")] static extern uint timeEndPeriod(uint ms);
    public static double CurrentMs() {
        uint a, b, c;
        if (NtQueryTimerResolution(out a, out b, out c) != 0) return 0;
        return c / 10000.0;
    }
    public static double BestMs() {
        uint a, b, c;
        if (NtQueryTimerResolution(out a, out b, out c) != 0) return 0;
        return b / 10000.0;
    }
    public static double Force(bool on) {
        uint a, b, c, actual = 0;
        if (NtQueryTimerResolution(out a, out b, out c) != 0) return 0;
        NtSetTimerResolution(b, on, out actual);
        if (on) timeBeginPeriod(1); else timeEndPeriod(1);
        return actual / 10000.0;
    }
    public static double[] SleepTest(int n) {
        Stopwatch sw = new Stopwatch();
        double sum = 0, max = 0;
        for (int i = 0; i < n; i++) {
            sw.Restart();
            Thread.Sleep(1);
            double ms = sw.Elapsed.TotalMilliseconds;
            sum += ms;
            if (ms > max) max = ms;
        }
        return new double[] { sum / n, max };
    }
}
'@
}

# ------------------------------------------------------------------ state / logging
$script:StateDir = Join-Path $env:ProgramData 'StrixTweaks'
$script:UndoDir  = Join-Path $script:StateDir 'undo'
New-Item -ItemType Directory -Force -Path $script:UndoDir | Out-Null
$script:LogFile = Join-Path $script:StateDir 'strix.log'
$script:LogBox  = $null
$script:Rec     = $null
$script:RPDone  = $false
$script:SearchText = ''

function Pump {
    if ($script:Cli) { return }
    $script:pumpFrame = New-Object System.Windows.Threading.DispatcherFrame
    [void][System.Windows.Threading.Dispatcher]::CurrentDispatcher.BeginInvoke(
        [System.Windows.Threading.DispatcherPriority]::Background,
        [Action]{ $script:pumpFrame.Continue = $false })
    [System.Windows.Threading.Dispatcher]::PushFrame($script:pumpFrame)
}

function Log([string]$m) {
    $line = '[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $m
    Add-Content -Path $script:LogFile -Value $line -ErrorAction SilentlyContinue
    if ($script:Cli) { Write-Host $line }
    if ($script:LogBox) { $script:LogBox.AppendText($line + "`r`n"); $script:LogBox.ScrollToEnd() }
}

# ------------------------------------------------------------------ undo engine
function Add-Rec($h) { [void]$script:Rec.Add($h) }

function Save-Rec([string]$id) {
    if ($script:Rec.Count -eq 0) { return }
    $json = ConvertTo-Json -InputObject @($script:Rec) -Depth 6
    Set-Content -Path (Join-Path $script:UndoDir "$id.json") -Value $json -Encoding UTF8
}

function Test-Applied([string]$id) { Test-Path (Join-Path $script:UndoDir "$id.json") }

function Set-Reg([string]$path, [string]$name, $value, [string]$type = 'DWord') {
    $existed = $false; $val = $null; $kind = $null
    try {
        $k = Get-Item -LiteralPath $path -ErrorAction Stop
        if ($k.GetValueNames() -contains $name) {
            $existed = $true
            $val  = $k.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            $kind = $k.GetValueKind($name).ToString()
        }
    } catch {}
    Add-Rec @{ t = 'reg'; path = $path; name = $name; existed = $existed; value = $val; kind = $kind }
    try {
        if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force | Out-Null }
        New-ItemProperty -LiteralPath $path -Name $name -Value $value -PropertyType $type -Force -ErrorAction Stop | Out-Null
    } catch { Log "  ! registry $name : $($_.Exception.Message)" }
}

function Set-Svc([string]$name, [string]$mode = 'Disabled') {
    $s = Get-CimInstance Win32_Service -Filter "Name='$name'" -ErrorAction SilentlyContinue
    if (-not $s) { return }
    Add-Rec @{ t = 'svc'; name = $name; mode = $s.StartMode; running = ($s.State -eq 'Running') }
    Set-Service -Name $name -StartupType $mode -ErrorAction SilentlyContinue
    if ($mode -eq 'Disabled') { Stop-Service -Name $name -Force -ErrorAction SilentlyContinue }
}

function Disable-Task([string]$full) {
    $i = $full.LastIndexOf('\'); $p = $full.Substring(0, $i + 1); $n = $full.Substring($i + 1)
    $t = Get-ScheduledTask -TaskPath $p -TaskName $n -ErrorAction SilentlyContinue
    if ($t -and $t.State -ne 'Disabled') {
        Add-Rec @{ t = 'task'; path = $p; name = $n }
        Disable-ScheduledTask -TaskPath $p -TaskName $n -ErrorAction SilentlyContinue | Out-Null
    }
}

function Add-UndoCmd([string]$cmd) { Add-Rec @{ t = 'cmd'; cmd = $cmd } }

function Restore-Records([string]$id) {
    $f = Join-Path $script:UndoDir "$id.json"
    if (-not (Test-Path $f)) { return }
    $recs = @(Get-Content $f -Raw | ConvertFrom-Json)
    [array]::Reverse($recs)
    foreach ($r in $recs) {
        try {
            switch ($r.t) {
                'reg' {
                    if ($r.existed) {
                        $v = $r.value
                        switch ($r.kind) {
                            'Binary'      { $v = [byte[]]@($v) }
                            'DWord'       { $v = [int]$v }
                            'QWord'       { $v = [int64]$v }
                            'MultiString' { $v = [string[]]@($v) }
                            default       { $v = [string]$v }
                        }
                        if (-not (Test-Path -LiteralPath $r.path)) { New-Item -Path $r.path -Force | Out-Null }
                        New-ItemProperty -LiteralPath $r.path -Name $r.name -Value $v -PropertyType $r.kind -Force | Out-Null
                    } else {
                        Remove-ItemProperty -LiteralPath $r.path -Name $r.name -ErrorAction SilentlyContinue
                    }
                }
                'svc' {
                    $m = if ($r.mode -eq 'Auto') { 'Automatic' } else { [string]$r.mode }
                    Set-Service -Name $r.name -StartupType $m -ErrorAction SilentlyContinue
                    if ($r.running) { Start-Service -Name $r.name -ErrorAction SilentlyContinue }
                }
                'task' { Enable-ScheduledTask -TaskPath $r.path -TaskName $r.name -ErrorAction SilentlyContinue | Out-Null }
                'cmd'  { Invoke-Expression $r.cmd 2>&1 | Out-Null }
            }
        } catch { Log "  ! undo step failed: $($_.Exception.Message)" }
    }
    Remove-Item $f -Force -ErrorAction SilentlyContinue
}

# ------------------------------------------------------------------ hardware detection
$cs      = Get-CimInstance Win32_ComputerSystem
$cpuInfo = Get-CimInstance Win32_Processor | Select-Object -First 1
$script:RamGB   = [math]::Round($cs.TotalPhysicalMemory / 1GB)
$script:Cores   = [int]$cpuInfo.NumberOfCores
$script:GpuName = ((Get-CimInstance Win32_VideoController | ForEach-Object { $_.Name }) -join ', ')
$chassis = @((Get-CimInstance Win32_SystemEnclosure).ChassisTypes)
$script:IsLaptop = ($null -ne (Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)) -or
                   (($chassis | Where-Object { $_ -in 8, 9, 10, 11, 14, 30, 31, 32 }).Count -gt 0)
$script:Build = [int](Get-CimInstance Win32_OperatingSystem).BuildNumber
$script:SysIsSSD = $true
try {
    $dn = (Get-Partition -DriveLetter $env:SystemDrive[0]).DiskNumber
    $script:SysIsSSD = ((Get-PhysicalDisk | Where-Object { $_.DeviceId -eq $dn }).MediaType -ne 'HDD')
} catch {}

$script:Suggest = 'Low-End'
if ($script:GpuName -match 'RTX|GTX 1[6-9]|GTX 1[0][5-8]|RX [5-9]\d{3}|Arc A|Radeon Pro' -and $script:RamGB -ge 12 -and $script:Cores -ge 4) { $script:Suggest = 'Mid-Range' }
if ($script:GpuName -match 'RTX (20[7-9]|30[6-9]|40|50)|RX (6[7-9]|7|9)\d' -and $script:RamGB -ge 24 -and $script:Cores -ge 8) { $script:Suggest = 'High-End' }

if ($Laptop) { $script:IsLaptop = $true } elseif ($Desktop) { $script:IsLaptop = $false }
$vcList = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | Where-Object { $_.Name -and $_.Name -notmatch 'Basic Render|Remote|Virtual|Parsec|Citrix|Meta|DisplayLink|Mirror' })
$script:Hybrid     = ($script:IsLaptop -and $vcList.Count -ge 2)
$script:HybridSafe = $script:Hybrid
if ($AllowHybridRisk) { $script:HybridSafe = $false }
$script:CpuHybrid  = [bool]($cpuInfo.Name -match 'Core\(TM\) Ultra|i[3579]-1[2-9]\d{3}|Core\(TM\) [3579] \d{3}')

# ------------------------------------------------------------------ tweak catalogue
$script:Tweaks = New-Object 'System.Collections.Generic.List[StrixTweak]'
$LevelName = @{ 1 = 'High/Mid/Low'; 2 = 'Mid/Low'; 3 = 'Low'; 4 = 'Menace only' }

function T([string]$Id, [string]$Cat, [string]$Name, [string]$Desc, [string]$Risk, [int]$Tier,
           [scriptblock]$Do, [switch]$NoLaptop, [switch]$Reboot) {
    $o = New-Object StrixTweak
    $o.Id = $Id; $o.Category = $Cat; $o.Name = $Name; $o.Desc = $Desc; $o.Risk = $Risk; $o.Tier = $Tier
    $o.Level = $LevelName[$Tier]; $o.NoLaptop = [bool]$NoLaptop; $o.Reboot = [bool]$Reboot; $o.Apply = $Do
    $script:Tweaks.Add($o)
}

# ===== TIER 1 : every preset (safe, worth it on any PC) ======================
T 'gpu.hags' 'GPU' 'Hardware-accelerated GPU scheduling (HAGS) ON' 'Lets the GPU manage its own VRAM scheduling. Lower CPU overhead and needed for DLSS Frame Generation. Needs a reboot and a GPU from the last ~5 years.' 'Safe' 1 {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 2
} -Reboot

T 'gpu.gamemode' 'GPU' 'Windows Game Mode ON' 'Tells Windows to prioritise the foreground game and pause driver installs / update restarts while you play.' 'Safe' 1 {
    Set-Reg 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1
    Set-Reg 'HKCU:\Software\Microsoft\GameBar' 'AllowAutoGameMode' 1
}

T 'gpu.windowed' 'GPU' 'Optimizations for windowed games (flip model)' 'Upgrades legacy DX10/11 windowed and borderless games to the low-latency flip presentation model. Borderless gets near-fullscreen latency. Existing per-user graphics settings are kept.' 'Safe' 1 {
    $k = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    $cur = [string](Get-ItemProperty -LiteralPath $k -Name DirectXUserGlobalSettings -ErrorAction SilentlyContinue).DirectXUserGlobalSettings
    $parts = @($cur -split ';' | Where-Object { $_ -and $_ -notmatch '^SwapEffectUpgradeEnable=' })
    $parts += 'SwapEffectUpgradeEnable=1'
    Set-Reg $k 'DirectXUserGlobalSettings' (($parts -join ';') + ';') 'String'
}

T 'gpu.dvr' 'GPU' 'Disable Xbox Game Bar / background capture (Game DVR)' 'Stops background recording hooks and Game Bar popups that cost frames and cause stutter. Use NVIDIA/AMD or OBS for recording instead.' 'Safe' 1 {
    Set-Reg 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 0
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' 'AppCaptureEnabled' 0
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR' 'AllowGameDVR' 0
    Set-Reg 'HKCU:\Software\Microsoft\GameBar' 'ShowStartupPanel' 0
    Set-Reg 'HKCU:\Software\Microsoft\GameBar' 'UseNexusForGameBarEnabled' 0
}

T 'sys.fastboot' 'System' 'Disable Fast Startup' 'Fast Startup keeps a half-hibernated kernel alive between boots, which causes driver weirdness and stale state. A real shutdown = a clean system.' 'Safe' 1 {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled' 0
}

T 'inp.mouse' 'Input' 'Raw mouse: disable pointer acceleration' 'Removes "Enhance pointer precision" so mouse movement is 1:1 with hand movement (consistent aim).' 'Safe' 1 {
    $p = 'HKCU:\Control Panel\Mouse'
    Set-Reg $p 'MouseSpeed' '0' 'String'
    Set-Reg $p 'MouseThreshold1' '0' 'String'
    Set-Reg $p 'MouseThreshold2' '0' 'String'
    Set-Reg $p 'MouseSensitivity' '10' 'String'
}

T 'inp.keyboard' 'Input' 'Keyboard: fastest repeat, kill Sticky/Filter key popups' 'Shortest repeat delay and fastest rate; disables the Shift x5 / Filter keys hotkey prompts that minimise your game.' 'Safe' 1 {
    Set-Reg 'HKCU:\Control Panel\Keyboard' 'KeyboardDelay' '0' 'String'
    Set-Reg 'HKCU:\Control Panel\Keyboard' 'KeyboardSpeed' '31' 'String'
    Set-Reg 'HKCU:\Control Panel\Accessibility\StickyKeys' 'Flags' '506' 'String'
    Set-Reg 'HKCU:\Control Panel\Accessibility\Keyboard Response' 'Flags' '122' 'String'
    Set-Reg 'HKCU:\Control Panel\Accessibility\ToggleKeys' 'Flags' '58' 'String'
}

T 'cpu.mmcss' 'CPU' 'Multimedia scheduler: game-first (MMCSS)' 'Removes network throttling, lowers background reservation and gives the "Games" scheduler task high GPU/CPU priority.' 'Safe' 1 {
    $sp = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
    Set-Reg $sp 'NetworkThrottlingIndex' -1
    Set-Reg $sp 'SystemResponsiveness' 10
    $g = "$sp\Tasks\Games"
    Set-Reg $g 'GPU Priority' 8
    Set-Reg $g 'Priority' 6
    Set-Reg $g 'Scheduling Category' 'High' 'String'
    Set-Reg $g 'SFIO Priority' 'High' 'String'
}

T 'cpu.throttle' 'CPU' 'Disable power throttling' 'Stops Windows from throttling background-classified processes (including game launchers / overlays / voice chat). Costs a little battery.' 'Safe' 1 {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' 1
} -NoLaptop

T 'net.do' 'Network' 'Disable Delivery Optimization (P2P updates)' 'Stops your PC uploading Windows updates to strangers and eating your bandwidth mid-match.' 'Safe' 1 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization' 'DODownloadMode' 0
}

T 'pri.telemetry' 'Privacy' 'Telemetry off (policy + DiagTrack service)' 'Sets telemetry to the minimum your edition allows and disables the Connected User Experiences service.' 'Safe' 1 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' 'AllowTelemetry' 0
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' 'DoNotShowFeedbackNotifications' 1
    Set-Svc 'DiagTrack'
    Set-Svc 'dmwappushservice'
}

T 'pri.ads' 'Privacy' 'Ads, tips, suggested apps, lock-screen junk off' 'Disables advertising ID, Start-menu suggestions, silent app installs and tips popups.' 'Safe' 1 {
    $c = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'
    foreach ($n in 'SubscribedContent-338387Enabled', 'SubscribedContent-338388Enabled', 'SubscribedContent-338389Enabled',
                   'SubscribedContent-353694Enabled', 'SubscribedContent-353696Enabled', 'SubscribedContent-310093Enabled',
                   'SystemPaneSuggestionsEnabled', 'SoftLandingEnabled', 'RotatingLockScreenEnabled',
                   'OemPreInstalledAppsEnabled', 'PreInstalledAppsEnabled', 'SilentInstalledAppsEnabled') { Set-Reg $c $n 0 }
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' 'Enabled' 0
}

T 'pri.activity' 'Privacy' 'Activity history / Timeline off' 'Stops Windows logging and syncing your activity.' 'Safe' 1 {
    $p = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System'
    Set-Reg $p 'EnableActivityFeed' 0
    Set-Reg $p 'PublishUserActivities' 0
    Set-Reg $p 'UploadUserActivities' 0
}

T 'pri.search' 'Privacy' 'Start-menu web (Bing) search off' 'Search stays local = faster, no network lookups every keystroke.' 'Safe' 1 {
    Set-Reg 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' 'DisableSearchBoxSuggestions' 1
}

T 'pri.copilot' 'Privacy' 'Copilot + Recall (AI data analysis) off' 'Disables Windows Copilot and Recall snapshotting - saves CPU/NPU/disk and a lot of privacy risk.' 'Safe' 1 {
    Set-Reg 'HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot' 'TurnOffWindowsCopilot' 1
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsAI' 'DisableAIDataAnalysis' 1
}

T 'fs.lastaccess' 'Disk' 'NTFS: stop updating last-access timestamps' 'Cuts a pointless disk write for every file read.' 'Safe' 1 {
    fsutil behavior set disablelastaccess 1 | Out-Null
    Add-UndoCmd 'fsutil behavior set disablelastaccess 2'
}

T 'ux.startupdelay' 'UI' 'Remove startup-app launch delay' 'Startup programs launch immediately instead of after a ~10 second artificial delay.' 'Safe' 1 {
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize' 'StartupDelayInMSec' 0
}

# ===== TIER 2 : mid-range + low-end ==========================================
T 'gpu.fso' 'GPU' 'Disable fullscreen optimizations globally' 'Forces classic exclusive-fullscreen behaviour. Lower input latency in many older DX11 titles; a few DX12 games prefer it on (use per-game profile instead if unsure).' 'Moderate' 2 {
    $p = 'HKCU:\System\GameConfigStore'
    Set-Reg $p 'GameDVR_FSEBehaviorMode' 2
    Set-Reg $p 'GameDVR_HonorUserFSEBehaviorMode' 1
    Set-Reg $p 'GameDVR_DXGIHonorFSEWindowsCompatible' 1
    Set-Reg $p 'GameDVR_EFSEFeatureFlags' 0
}

T 'cpu.prio' 'CPU' 'Foreground priority boost (Win32PrioritySeparation = 0x26)' 'Short, fixed quanta with maximum foreground boost: the game window gets CPU first. Classic latency tweak.' 'Safe' 1 {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 38
}

T 'cpu.timer' 'CPU' 'Global timer resolution requests' 'Restores pre-Win11 behaviour so a game asking for 1 ms timer resolution benefits system-wide. Smoother frame pacing, slightly higher idle power.' 'Safe' 1 {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel' 'GlobalTimerResolutionRequests' 1
} -NoLaptop -Reboot

T 'net.qos' 'Network' 'Remove QoS bandwidth reservation' 'Makes sure Windows does not hold back bandwidth for QoS traffic.' 'Safe' 1 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Psched' 'NonBestEffortLimit' 0
}

T 'upd.drivers' 'Updates' 'Stop Windows Update replacing graphics drivers' 'Keeps the GPU driver you installed instead of whatever Windows Update pushes.' 'Safe' 1 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' 'ExcludeWUDriversInQualityUpdate' 1
    Set-Reg 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' 'SearchOrderConfig' 0
}

T 'pri.bg' 'Background' 'Block background apps' 'UWP/Store apps cannot run in the background eating CPU and RAM.' 'Safe' 2 {
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' 'GlobalUserDisabled' 1
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' 'LetAppsRunInBackground' 2
}

T 'pri.tasks' 'Background' 'Disable telemetry scheduled tasks' 'Turns off Compatibility Appraiser, CEIP, error-reporting queue and disk-diagnostic collectors that wake up and hit CPU/disk.' 'Safe' 2 {
    foreach ($t in '\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser',
                   '\Microsoft\Windows\Application Experience\ProgramDataUpdater',
                   '\Microsoft\Windows\Application Experience\StartupAppTask',
                   '\Microsoft\Windows\Customer Experience Improvement Program\Consolidator',
                   '\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip',
                   '\Microsoft\Windows\Windows Error Reporting\QueueReporting',
                   '\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector',
                   '\Microsoft\Windows\Feedback\Siuf\DmClient',
                   '\Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload') { Disable-Task $t }
}

T 'pri.wer' 'Background' 'Windows Error Reporting off' 'No crash-dump uploads / dialogs.' 'Safe' 1 {
    Set-Reg 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting' 'Disabled' 1
}

T 'svc.safe' 'Services' 'Disable useless services (safe list)' 'Remote Registry, Fax, Retail Demo, Maps, Geolocation, Media Sharing, Insider, Phone, Wallet, NVIDIA telemetry container.' 'Safe' 2 {
    foreach ($s in 'RemoteRegistry', 'Fax', 'RetailDemo', 'MapsBroker', 'lfsvc', 'WMPNetworkSvc', 'wisvc', 'PhoneSvc', 'WalletService', 'NvTelemetryContainer') { Set-Svc $s }
}

T 'svc.sysmain' 'Services' 'Disable SysMain (Superfetch)' 'Stops constant background disk reads / RAM preloading. Great on SSD, skipped automatically if Windows is on a hard drive.' 'Safe' 2 {
    if (-not $script:SysIsSSD) { Log '  skipped: Windows is on an HDD (SysMain helps there)'; return }
    Set-Svc 'SysMain'
}

T 'ux.widgets' 'UI' 'Remove Widgets / Chat / search box from taskbar' 'Kills the Widgets (news) process and taskbar clutter. Reclaims RAM and CPU.' 'Safe' 2 {
    $a = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
    Set-Reg $a 'TaskbarDa' 0
    Set-Reg $a 'TaskbarMn' 0
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'SearchboxTaskbarMode' 0
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Dsh' 'AllowNewsAndInterests' 0
}

T 'ux.transp' 'UI' 'Disable transparency effects' 'Acrylic/blur costs GPU time. Windows looks flatter, games get a little more headroom on weak GPUs.' 'Safe' 2 {
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' 'EnableTransparency' 0
}

T 'ux.menu' 'UI' 'Snappier UI + faster shutdown timeouts' 'Zero menu delay; hung apps are killed after 3 s instead of 20 s.' 'Safe' 2 {
    $d = 'HKCU:\Control Panel\Desktop'
    Set-Reg $d 'MenuShowDelay' '0' 'String'
    Set-Reg $d 'AutoEndTasks' '1' 'String'
    Set-Reg $d 'HungAppTimeout' '3000' 'String'
    Set-Reg $d 'WaitToKillAppTimeout' '3000' 'String'
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control' 'WaitToKillServiceTimeout' '3000' 'String'
}

T 'mem.paging' 'Memory' 'Keep kernel/drivers in RAM (DisablePagingExecutive)' 'Stops Windows paging kernel code to disk. Only applied with 16 GB+ RAM.' 'Moderate' 2 {
    if ($script:RamGB -lt 16) { Log '  skipped: needs 16 GB+ RAM'; return }
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' 'DisablePagingExecutive' 1
}

T 'edge.bg' 'Background' 'Edge: no startup boost / background mode' 'Edge stops pre-loading and running after you close it.' 'Safe' 1 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'StartupBoostEnabled' 0
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'BackgroundModeEnabled' 0
}

T 'def.cpu' 'Security' 'Defender: low-CPU, idle-only scans (stays ON)' 'Keeps real-time protection but caps scan CPU at 10% so scans do not tank FPS.' 'Safe' 1 {
    try {
        $old = (Get-MpPreference).ScanAvgCPULoadFactor
        Add-UndoCmd "Set-MpPreference -ScanAvgCPULoadFactor $old"
        Set-MpPreference -ScanAvgCPULoadFactor 10
    } catch { Log '  ! Defender not available' }
}

T 'ra.off' 'Services' 'Remote Assistance off' 'Closes the Remote Assistance invitation feature.' 'Safe' 1 {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' 'fAllowToGetHelp' 0
}

# ===== TIER 3 : low-end PCs (and Menace) =====================================
T 'gpu.mpo' 'GPU' 'Disable Multiplane Overlay (MPO)' 'Fixes stutter, flicker and black screens on many NVIDIA/AMD setups with multi-monitor or borderless games. On hybrid-graphics laptops (Optimus / Advanced Optimus / MUX) it is SKIPPED while "Optimus/MUX safety" is ticked, because display-path changes can cause black screens when the laptop switches between iGPU and dGPU.' 'Moderate' 3 {
    if ($script:Hybrid -and $script:HybridSafe) {
        Log '  skipped: hybrid-graphics laptop (Optimus/MUX). Untick "Optimus/MUX safety" to force it. If the screen ever goes black: Win+Ctrl+Shift+B, or Safe Mode + REVERT EVERYTHING.'
        return
    }
    Set-Reg 'HKLM:\SOFTWARE\Microsoft\Windows\Dwm' 'OverlayTestMode' 5
} -Reboot

T 'ux.anim' 'UI' 'Best-performance visual effects (no animations)' 'Turns off window/taskbar animations, shadows and Aero Peek. Windows feels instant on weak hardware.' 'Safe' 3 {
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' 2
    Set-Reg 'HKCU:\Control Panel\Desktop\WindowMetrics' 'MinAnimate' '0' 'String'
    $a = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
    Set-Reg $a 'TaskbarAnimations' 0
    Set-Reg $a 'ListviewAlphaSelect' 0
    Set-Reg $a 'ListviewShadow' 0
    Set-Reg 'HKCU:\Software\Microsoft\Windows\DWM' 'EnableAeroPeek' 0
}

T 'pwr.plan' 'Power' 'Strix Performance power plan (Ultimate, no parking/idle)' 'Creates a new power plan: 100% min CPU, no core parking, no USB/PCIe power saving, aggressive boost. Your old plan is restored on revert. Desktop only.' 'Moderate' 3 {
    $cur = (powercfg /getactivescheme) -replace '.*GUID:\s*([0-9a-fA-F-]{36}).*', '$1'
    $out = powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 2>&1 | Out-String
    if ($out -notmatch '([0-9a-fA-F-]{36})') { $out = powercfg -duplicatescheme 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2>&1 | Out-String }
    if ($out -notmatch '([0-9a-fA-F-]{36})') { throw 'could not create power scheme' }
    $new = $Matches[1]
    powercfg -changename $new 'Strix Performance' 'Created by Strix Tweaks 1.6' | Out-Null
    Add-UndoCmd "powercfg /setactive $cur; powercfg /delete $new"
    $cpu = '54533251-82be-4824-96c1-47b60b740d00'
    $set = @(
        @($cpu, '893dee8e-2bef-41e0-89c6-b55d0929964c', 100),   # min processor state
        @($cpu, 'bc5038f7-23e0-4960-96da-33abaf5935ec', 100),   # max processor state
        @($cpu, '0cc5b647-c1df-4637-891a-dec35c318583', 100),   # core parking min cores
        @($cpu, 'be337238-0d82-4146-a960-4f3749d470c7', 2),     # boost mode aggressive
        @('2a737441-1930-4402-8d77-b2bebba308a3', '48e6b7a6-50f5-4de8-9ae8-5c5fa7dc6ae0', 0),  # USB selective suspend off
        @('501a4d13-42af-4429-9fd1-a8218c268e20', 'ee12f906-d277-404b-b6da-e5fa1a576df5', 0),  # PCIe link state off
        @('0012ee47-9041-4b5d-9b77-535fba8b1442', '6738e2c4-e8a5-4a42-b16a-e040e769756e', 0)   # disk never sleeps
    )
    foreach ($x in $set) { powercfg /setacvalueindex $new $x[0] $x[1] $x[2] 2>&1 | Out-Null }
    powercfg /setactive $new | Out-Null
} -NoLaptop

T 'pwr.hib' 'Power' 'Disable hibernation (frees disk, no Fast Startup)' 'Deletes hiberfil.sys (several GB). You lose Hibernate.' 'Moderate' 3 {
    $h = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -ErrorAction SilentlyContinue).HibernateEnabled
    if ($h -ne 1) { Log '  skipped: hibernation already off'; return }
    powercfg /h off | Out-Null
    Add-UndoCmd 'powercfg /h on'
} -NoLaptop -Reboot

T 'cpu.bcd' 'CPU' 'Kernel timer tuning (dynamic tick off, enhanced TSC sync)' 'Disables the tickless kernel timer and uses the enhanced TSC policy. Lower timer jitter / frame-time variance on many CPUs. Raises idle power.' 'Moderate' 3 {
    bcdedit /set disabledynamictick yes | Out-Null
    Add-UndoCmd 'bcdedit /deletevalue disabledynamictick'
    bcdedit /set tscsyncpolicy enhanced | Out-Null
    Add-UndoCmd 'bcdedit /deletevalue tscsyncpolicy'
} -NoLaptop -Reboot

T 'net.nagle' 'Network' 'Disable Nagle / delayed ACK on all interfaces' 'Sends small TCP packets immediately. Helps TCP-based games, launchers and voice; UDP games are unaffected.' 'Moderate' 3 {
    Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces' -ErrorAction SilentlyContinue | ForEach-Object {
        Set-Reg $_.PSPath 'TcpAckFrequency' 1
        Set-Reg $_.PSPath 'TCPNoDelay' 1
    }
}

T 'net.adapter' 'Network' 'Network adapters: never power down' 'Disables "allow the computer to turn off this device to save power" on physical NICs (stops lag spikes after idle).' 'Safe' 3 {
    $base = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}'
    Get-ChildItem $base -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^\d{4}$' } | ForEach-Object {
        $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
        if ($p.NetCfgInstanceId -and $p.DriverDesc -and $p.DriverDesc -notmatch 'Virtual|Miniport|VPN|Hyper-V|VMware|Bluetooth|Tunnel|TAP|WAN') {
            Set-Reg $_.PSPath 'PnPCapabilities' 24
        }
    }
} -NoLaptop -Reboot

T 'svc.aggr' 'Services' 'Disable more services (aggressive list)' 'Program Compatibility Assistant, UPnP/SSDP discovery, Diagnostic Policy + WDI, Tablet Input, Link Tracking, Offline Files, Diagnostics Hub.' 'Moderate' 3 {
    foreach ($s in 'PcaSvc', 'SSDPSRV', 'upnphost', 'DPS', 'WdiServiceHost', 'WdiSystemHost', 'TabletInputService', 'TrkWks', 'diagnosticshub.standardcollector.service', 'CscService') { Set-Svc $s }
}

T 'svc.wsearch' 'Services' 'Windows Search indexer -> manual' 'Stops constant indexing disk/CPU. Start-menu file search gets slower.' 'Moderate' 3 {
    Set-Svc 'WSearch' 'Manual'
    Stop-Service 'WSearch' -Force -ErrorAction SilentlyContinue
}

T 'mem.compress' 'Memory' 'Disable memory compression' 'Saves CPU cycles on systems with plenty of RAM. Only applied with 16 GB+ RAM.' 'Moderate' 3 {
    if ($script:RamGB -lt 16) { Log '  skipped: needs 16 GB+ RAM'; return }
    if ((Get-MMAgent).MemoryCompression) {
        Disable-MMAgent -MemoryCompression
        Add-UndoCmd 'Enable-MMAgent -MemoryCompression'
    }
} -Reboot

T 'mem.prefetch' 'Memory' 'Disable Prefetch / Superfetch registry flags' 'Pairs with SysMain off. Skipped when Windows lives on a hard drive.' 'Moderate' 3 {
    if (-not $script:SysIsSSD) { Log '  skipped: Windows is on an HDD'; return }
    $p = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters'
    Set-Reg $p 'EnablePrefetcher' 0
    Set-Reg $p 'EnableSuperfetch' 0
}

T 'pri.onedrive' 'Background' 'OneDrive sync off (policy)' 'OneDrive stops running and syncing. Your files stay where they are.' 'Moderate' 3 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\OneDrive' 'DisableFileSyncNGSC' 1
}

T 'ux.toast' 'UI' 'Disable toast notifications' 'No popups over your game. (Turn back on by reverting.)' 'Safe' 3 {
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\PushNotifications' 'ToastEnabled' 0
}

T 'pri.store' 'Background' 'Microsoft Store: no auto-downloading app updates' 'Stops the Store downloading updates in the background mid-game.' 'Safe' 3 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore' 'AutoDownload' 2
}

# ===== TIER 4 : MENACE ONLY (real FPS, real trade-offs) ======================
T 'sec.vbs' 'Security' 'Turn off VBS / Memory Integrity (HVCI)' 'Biggest "free" FPS on many CPUs (5-10% in CPU-bound games). Removes a major kernel security layer. Windows may re-enable it after feature updates.' 'Risky' 4 {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' 'EnableVirtualizationBasedSecurity' 0
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' 'Enabled' 0
} -Reboot

T 'sec.spectre' 'Security' 'Disable Spectre/Meltdown mitigations' 'Small gain on older Intel/AMD CPUs. Re-opens CPU side-channel vulnerabilities. Do not use on a PC that browses sketchy sites.' 'Risky' 4 {
    $p = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'
    Set-Reg $p 'FeatureSettingsOverride' 3
    Set-Reg $p 'FeatureSettingsOverrideMask' 3
} -Reboot

T 'sec.defender' 'Security' 'Defender real-time protection OFF' 'Removes scan overhead while loading/playing. Your PC has NO live antivirus. Fails if Tamper Protection is on (turn it off in Windows Security first).' 'Risky' 4 {
    try {
        $old = (Get-MpPreference).DisableRealtimeMonitoring
        if ($old) { Add-UndoCmd 'Set-MpPreference -DisableRealtimeMonitoring $true' } else { Add-UndoCmd 'Set-MpPreference -DisableRealtimeMonitoring $false' }
        Set-MpPreference -DisableRealtimeMonitoring $true
        if ((Get-MpPreference).DisableRealtimeMonitoring -ne $true) { Log '  ! blocked by Tamper Protection - turn it off in Windows Security > Virus & threat protection' }
    } catch { Log '  ! Defender not available' }
}

T 'sec.smartscreen' 'Security' 'SmartScreen off' 'No reputation checks when launching downloaded .exe files.' 'Risky' 4 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' 'EnableSmartScreen' 0
    Set-Reg 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' 'SmartScreenEnabled' 'Off' 'String'
}

T 'svc.xbox' 'Services' 'Disable Xbox services' 'Breaks Xbox app sign-in, Game Pass / Store games and Xbox accessory features. Fine for Steam/Epic/Battle.net-only PCs.' 'Risky' 4 {
    foreach ($s in 'XblAuthManager', 'XblGameSave', 'XboxGipSvc', 'XboxNetApiSvc') { Set-Svc $s }
}

T 'svc.print' 'Services' 'Disable Print Spooler' 'No printing at all. Also removes a frequent attack surface.' 'Risky' 4 {
    Set-Svc 'Spooler'
}

T 'cpu.hyperv' 'CPU' 'Disable hypervisor launch (Hyper-V / virtualization platform)' 'Removes hypervisor overhead on some systems. Breaks WSL2, Docker, Windows Sandbox, VMs and Core Isolation.' 'Risky' 4 {
    bcdedit /set hypervisorlaunchtype off | Out-Null
    Add-UndoCmd 'bcdedit /set hypervisorlaunchtype auto'
} -Reboot

# ===================================================================== EXPANSION PACK =====================================================================
# --- helpers used by the expansion tweaks
function Get-StrixScheme {
    $l = powercfg /list | Out-String
    if ($l -match '([0-9a-fA-F-]{36})\s+\(Strix Performance\)') { return $Matches[1] }
    return $null
}

function Add-PlanAddon([string]$sub, [string]$set, [int]$val) {
    $g = Get-StrixScheme
    if (-not $g) {
        $a = powercfg /getactivescheme | Out-String
        if ($a -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') { $g = $Matches[1] }
        if (-not $g) { Log '  skipped: could not read the active power plan'; return $false }
        Log '  (no Strix plan yet: editing your active power plan; undo restores the old value)'
    }
    $q = powercfg /query $g $sub $set 2>&1 | Out-String
    if ($q -notmatch 'Current AC Power Setting Index:\s*0x([0-9a-fA-F]+)') { Log '  skipped: this power setting does not exist on this CPU / Windows build'; return $false }
    $prev = [Convert]::ToUInt32($Matches[1], 16)
    Add-UndoCmd "powercfg /setacvalueindex $g $sub $set $prev; powercfg /setactive $g"
    powercfg /setacvalueindex $g $sub $set $val 2>&1 | Out-Null
    powercfg /setactive $g | Out-Null
    return $true
}

function Set-AdvProp([string]$adapter, [string]$display, [string]$pattern) {
    try {
        $p = Get-NetAdapterAdvancedProperty -Name $adapter -DisplayName $display -ErrorAction Stop
        $val = @($p.ValidDisplayValues | Where-Object { $_ -match $pattern }) | Select-Object -First 1
        if (-not $val) { return }
        if ($p.DisplayValue -eq $val) { return }
        $prev = $p.DisplayValue
        Set-NetAdapterAdvancedProperty -Name $adapter -DisplayName $display -DisplayValue $val -ErrorAction Stop
        Add-UndoCmd ("Set-NetAdapterAdvancedProperty -Name '{0}' -DisplayName '{1}' -DisplayValue '{2}'" -f $adapter, $display, $prev)
        Log "  $adapter : $display -> $val"
    } catch {}
}

# ===== GPU ====================================================================
T 'gpu.tdr' 'GPU' 'Raise GPU driver timeout (TDR) to 10 s' 'Stops "display driver stopped responding" crashes and black screens under heavy load or shader compilation. Stability, not FPS.' 'Safe' 1 {
    $p = 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'
    Set-Reg $p 'TdrDelay' 10
    Set-Reg $p 'TdrDdiDelay' 10
} -Reboot

T 'gpu.nvtasks' 'GPU' 'NVIDIA: disable telemetry + update-check tasks' 'Disables NvTm* telemetry tasks and the daily driver update check that wake the CPU and disk. Your driver keeps working; update manually.' 'Safe' 1 {
    Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -match '^(NvTm|NvDriverUpdateCheck)' } | ForEach-Object {
        Disable-Task ($_.TaskPath + $_.TaskName)
    }
}

T 'gpu.powermizer' 'GPU' 'NVIDIA: lock max-performance power state (PowerMizer)' 'Stops the GPU downclocking between frames in lighter games = steadier frame times. GPU runs hotter and uses more power at idle. Desktop only.' 'Moderate' 3 {
    $base = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
    Get-ChildItem $base -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^\d{4}$' } | ForEach-Object {
        $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
        if ($p.DriverDesc -match 'NVIDIA') {
            Log "  PowerMizer: $($p.DriverDesc)"
            Set-Reg $_.PSPath 'PowerMizerEnable' 1
            Set-Reg $_.PSPath 'PowerMizerLevel' 1
            Set-Reg $_.PSPath 'PowerMizerLevelAC' 1
            Set-Reg $_.PSPath 'PerfLevelSrc' 8738
        }
    }
} -NoLaptop -Reboot

T 'gpu.msi' 'Latency' 'MSI interrupt mode for GPU + network cards' 'Message-Signaled Interrupts give lower-latency, less-shared interrupts for PCI graphics and network adapters. Most modern drivers already use it; this forces it on.' 'Moderate' 3 {
    Get-PnpDevice -PresentOnly -Class Display, Net -ErrorAction SilentlyContinue | Where-Object { $_.InstanceId -like 'PCI\*' } | ForEach-Object {
        $k = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($_.InstanceId)\Device Parameters\Interrupt Management\MessageSignaledInterruptProperties"
        Log "  MSI: $($_.FriendlyName)"
        Set-Reg $k 'MSISupported' 1
    }
} -Reboot

# ===== CPU ====================================================================
T 'cpu.mmcss2' 'CPU' 'MMCSS: mark the Games task latency-sensitive' 'Adds the Latency Sensitive flag, foreground-only clock rate and no background-only mode to the Games scheduler task.' 'Safe' 1 {
    $g = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'
    Set-Reg $g 'Background Only' 'False' 'String'
    Set-Reg $g 'Clock Rate' 10000
    Set-Reg $g 'Latency Sensitive' 'True' 'String'
}

T 'cpu.fth' 'CPU' 'Disable Fault Tolerant Heap' 'After a few crashes Windows silently applies slow "shims" to a game exe. This stops that from tanking performance.' 'Safe' 1 {
    Set-Reg 'HKLM:\SOFTWARE\Microsoft\FTH' 'Enabled' 0
}

T 'cpu.hpet' 'CPU' 'Make sure HPET is not forced as system timer' 'Removes a forced "useplatformclock" boot flag (a common leftover from old tweak guides) which adds timer latency. Does nothing if not set.' 'Safe' 1 {
    $e = bcdedit /enum '{current}' | Out-String
    if ($e -match 'useplatformclock') {
        bcdedit /deletevalue useplatformclock | Out-Null
        Add-UndoCmd 'bcdedit /set useplatformclock true'
    } else { Log '  not forced - nothing to do' }
} -Reboot

T 'pwr.idle' 'CPU' 'Disable CPU idle states (C-states) on the Strix plan' 'Cores never sleep: lowest wake-up latency, hottest and most power-hungry. Edits the Strix plan if it exists, otherwise your active plan.' 'Moderate' 4 {
    [void](Add-PlanAddon '54533251-82be-4824-96c1-47b60b740d00' '5d76a2ca-e8c0-402f-a133-2158492d58ad' 1)
} -NoLaptop

# ===== POWER ==================================================================
T 'pwr.overlay' 'Power' 'Power mode: Best performance when plugged in' 'Sets the Windows 11 "Power mode" slider to Best performance on AC. Works on desktops and laptops (battery mode untouched).' 'Safe' 1 {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes' 'ActiveOverlayAcPowerScheme' 'ded574b5-45a0-4f42-8737-46345c09c238' 'String'
}

# ===== STORAGE (SSD / HDD) ====================================================
T 'sto.trim' 'Storage' 'SSD: make sure TRIM is enabled' 'TRIM lets the SSD clean freed blocks so write speed stays high. Windows normally has it on; this verifies and fixes it. Skipped on HDD.' 'Safe' 1 {
    if (-not $script:SysIsSSD) { Log '  skipped: Windows is on an HDD'; return }
    $o = fsutil behavior query DisableDeleteNotify | Out-String
    if ($o -match 'NTFS DisableDeleteNotify\s*=\s*(\d)') {
        $prev = $Matches[1]
        if ($prev -ne '0') { fsutil behavior set DisableDeleteNotify 0 | Out-Null; Add-UndoCmd "fsutil behavior set DisableDeleteNotify $prev" }
        else { Log '  TRIM already enabled' }
    }
}

T 'sto.8dot3' 'Storage' 'NTFS: stop creating legacy 8.3 filenames' 'Every new file no longer gets a second short DOS-style name. Less metadata work on SSD and HDD. May affect very old 16-bit installers.' 'Safe' 1 {
    $o = fsutil behavior query disable8dot3 | Out-String
    if ($o -match 'state is:\s*(\d)') {
        $prev = $Matches[1]
        if ($prev -ne '1') { fsutil behavior set disable8dot3 1 | Out-Null; Add-UndoCmd "fsutil behavior set disable8dot3 $prev" }
    }
}

T 'sto.ntfsmem' 'Storage' 'NTFS: larger metadata cache' 'Lets NTFS use more paged pool for file-system metadata caching. Faster directory/file lookups in big game libraries. Only applied with 16 GB+ RAM.' 'Safe' 3 {
    if ($script:RamGB -lt 16) { Log '  skipped: needs 16 GB+ RAM'; return }
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' 'NtfsMemoryUsage' 2
}

T 'sto.mft' 'Storage' 'NTFS: bigger MFT zone (less fragmentation)' 'Reserves more space for the master file table. Mostly helps hard drives with many small files. Harmless on SSD.' 'Safe' 3 {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' 'NtfsMftZoneReservation' 2
}

T 'sto.sense' 'Storage' 'Storage Sense: no automatic cleanup runs' 'Stops Storage Sense from deleting files and running cleanup jobs in the background while you play.' 'Safe' 2 {
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy' '01' 0
}

T 'sto.reserved' 'Storage' 'Disable Reserved Storage (frees ~7 GB)' 'Gives back the disk space Windows holds for updates. Updates may fail if the drive gets completely full. Can take a minute.' 'Moderate' 3 {
    $o = DISM /Online /Get-ReservedStorageState | Out-String
    if ($o -match 'Reserved storage is enabled') {
        Log '  (DISM is working, this can take a minute)'; Pump
        DISM /Online /Set-ReservedStorageState /State:Disabled | Out-Null
        Add-UndoCmd 'DISM /Online /Set-ReservedStorageState /State:Enabled'
    } else { Log '  already disabled (or not detected)' }
} -Reboot

T 'sto.dump' 'Storage' 'Small crash dumps only' 'Writes a small dump instead of a multi-GB kernel/full memory dump after a blue screen. Saves disk space and write time.' 'Safe' 2 {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl' 'CrashDumpEnabled' 3
}

# ===== MEMORY (RAM) ===========================================================
T 'ram.svchost' 'Memory' 'Fewer svchost processes (split threshold = RAM)' 'Services share host processes instead of each getting its own, saving a little RAM and process-creation overhead. Only applied with 16 GB+ RAM.' 'Moderate' 3 {
    if ($script:RamGB -lt 16) { Log '  skipped: needs 16 GB+ RAM'; return }
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control' 'SvcHostSplitThresholdInKB' ([int]($script:RamGB * 1024 * 1024))
} -Reboot

T 'ram.mmagent' 'Memory' 'Disable app-launch prefetching / pre-launch' 'Stops Windows pre-loading apps into RAM based on past use. Frees RAM and disk activity on SSD systems. Skipped on HDD.' 'Moderate' 3 {
    if (-not $script:SysIsSSD) { Log '  skipped: Windows is on an HDD'; return }
    $m = Get-MMAgent
    if ($m.ApplicationLaunchPrefetching) { Disable-MMAgent -ApplicationLaunchPrefetching; Add-UndoCmd 'Enable-MMAgent -ApplicationLaunchPrefetching' }
    if ($m.ApplicationPreLaunch) { Disable-MMAgent -ApplicationPreLaunch; Add-UndoCmd 'Enable-MMAgent -ApplicationPreLaunch' }
} -Reboot

# ===== NETWORK / WI-FI / LATENCY ==============================================
T 'net.tcp' 'Network' 'TCP stack: RSS on, RSC off, ECN off, timestamps off' 'Spreads network work across cores (RSS) and turns off packet coalescing (RSC), ECN and timestamps for lower per-packet latency and overhead.' 'Moderate' 3 {
    $show = netsh int tcp show global | Out-String
    $items = @(
        @('Receive-Side Scaling State', 'rss', 'enabled'),
        @('Receive Segment Coalescing State', 'rsc', 'disabled'),
        @('ECN Capability', 'ecncapability', 'disabled'),
        @('RFC 1323 Timestamps', 'timestamps', 'disabled')
    )
    foreach ($i in $items) {
        if ($show -match ([regex]::Escape($i[0]) + '\s*:\s*(\w+)')) {
            $prev = $Matches[1]
            if ($prev -ne $i[2]) {
                netsh int tcp set global ($i[1] + '=' + $i[2]) | Out-Null
                Add-UndoCmd ('netsh int tcp set global {0}={1}' -f $i[1], $prev)
                Log "  $($i[1]): $prev -> $($i[2])"
            }
        }
    }
}

T 'net.tcpreg' 'Network' 'TCP registry: faster port recycling' 'Shorter TIME_WAIT (30 s) and a bigger ephemeral port range. Helps launchers, downloads and many simultaneous connections.' 'Safe' 2 {
    $p = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters'
    Set-Reg $p 'TcpTimedWaitDelay' 30
    Set-Reg $p 'MaxUserPort' 65534
}

T 'net.dns' 'Network' 'DNS: Cloudflare 1.1.1.1 / 1.0.0.1 on active adapters' 'Fast resolver for game servers, launchers and web. Your previous DNS (static or automatic) is restored on revert.' 'Safe' 3 {
    $ads = Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' }
    foreach ($a in $ads) {
        $idx = $a.ifIndex
        $ns = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$($a.InterfaceGuid)" -ErrorAction SilentlyContinue).NameServer
        if ($ns) {
            $list = (($ns -split '[,\s]+') | Where-Object { $_ }) -join "','"
            Add-UndoCmd ("Set-DnsClientServerAddress -InterfaceIndex {0} -ServerAddresses ('{1}')" -f $idx, $list)
        } else {
            Add-UndoCmd ("Set-DnsClientServerAddress -InterfaceIndex {0} -ResetServerAddresses" -f $idx)
        }
        Set-DnsClientServerAddress -InterfaceIndex $idx -ServerAddresses ('1.1.1.1', '1.0.0.1') -ErrorAction SilentlyContinue
        Log "  DNS set on $($a.Name)"
    }
    ipconfig /flushdns | Out-Null
}

T 'net.wifi' 'Wi-Fi' 'Wi-Fi adapter: low-latency driver settings' 'Per driver: lowest roaming aggressiveness, throughput booster, no U-APSD / MIMO power save / packet coalescing, highest TX power, prefer 5 GHz. Only options your driver offers are changed. Wi-Fi may blink for a second.' 'Moderate' 3 {
    $ads = Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' -and $_.PhysicalMediaType -match '802\.11' }
    if (-not $ads) { Log '  no active Wi-Fi adapter found'; return }
    foreach ($a in $ads) {
        Set-AdvProp $a.Name 'Roaming Aggressiveness' 'Lowest'
        Set-AdvProp $a.Name 'Roaming Sensitivity Level' 'Lowest'
        Set-AdvProp $a.Name 'Throughput Booster' 'Enabled'
        Set-AdvProp $a.Name 'U-APSD support' 'Disabled'
        Set-AdvProp $a.Name 'Packet Coalescing' 'Disabled'
        Set-AdvProp $a.Name 'MIMO Power Save Mode' 'No SMPS'
        Set-AdvProp $a.Name 'Transmit Power' 'Highest'
        Set-AdvProp $a.Name 'Power Saving Mode' 'Disabled|Off|Maximum Performance'
        Set-AdvProp $a.Name 'Sleep on WoWLAN Disconnect' 'Disabled'
        Set-AdvProp $a.Name 'Interrupt Moderation' 'Disabled'
        Set-AdvProp $a.Name 'Preferred Band' 'Prefer 5'
    }
}

T 'net.eth' 'Network' 'Ethernet adapter: low-latency driver settings' 'Disables Energy-Efficient/Green Ethernet, interrupt moderation, flow control and large-send offload for the lowest latency. Slightly higher CPU use. Link blinks for a second.' 'Moderate' 3 {
    $ads = Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' -and $_.PhysicalMediaType -match '802\.3' }
    if (-not $ads) { Log '  no active Ethernet adapter found'; return }
    foreach ($a in $ads) {
        Set-AdvProp $a.Name 'Energy Efficient Ethernet' 'Disabled|Off'
        Set-AdvProp $a.Name 'Green Ethernet' 'Disabled|Off'
        Set-AdvProp $a.Name 'Advanced EEE' 'Disabled'
        Set-AdvProp $a.Name 'Gigabit Lite' 'Disabled'
        Set-AdvProp $a.Name 'Ultra Low Power Mode' 'Disabled'
        Set-AdvProp $a.Name 'Power Saving Mode' 'Disabled|Off'
        Set-AdvProp $a.Name 'Interrupt Moderation' 'Disabled'
        Set-AdvProp $a.Name 'Flow Control' 'Disabled'
        Set-AdvProp $a.Name 'Large Send Offload V2 (IPv4)' 'Disabled'
        Set-AdvProp $a.Name 'Large Send Offload V2 (IPv6)' 'Disabled'
    }
}

T 'net.ndu' 'Network' 'Disable Network Data Usage monitor (NDU)' 'Fixes the known NDU non-paged-pool memory growth and removes a driver that inspects network traffic. Per-app data usage stats disappear.' 'Safe' 3 {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Services\Ndu' 'Start' 4
} -Reboot

T 'net.netbios' 'Network' 'Disable NetBIOS over TCP/IP' 'Removes legacy NetBIOS broadcast chatter. Old-style Windows network name lookup on a LAN can stop working.' 'Moderate' 3 {
    Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces' -ErrorAction SilentlyContinue | ForEach-Object {
        Set-Reg $_.PSPath 'NetbiosOptions' 2
    }
}

T 'net.llmnr' 'Network' 'Disable LLMNR multicast name resolution' 'Removes extra multicast name queries (also a known spoofing vector).' 'Safe' 1 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' 'EnableMulticast' 0
}

T 'inp.usb' 'Latency' 'USB: disable selective suspend' 'Stops Windows powering down USB ports/hubs, which causes mouse/keyboard/headset wake-up lag and dropouts.' 'Safe' 1 {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Services\USB' 'DisableSelectiveSuspend' 1
} -NoLaptop

# ===== SYSTEM / PRIVACY / BACKGROUND (everything else) =========================
T 'sys.cloud' 'Privacy' 'Block auto-installed consumer apps' 'Windows stops silently installing sponsored apps and games (Candy Crush style) after updates.' 'Safe' 1 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' 'DisableWindowsConsumerFeatures' 1
}

T 'sys.search' 'Privacy' 'Search: no Cortana, web results or location' 'Fully local Windows Search. Less network and background work.' 'Safe' 1 {
    $p = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search'
    Set-Reg $p 'AllowCortana' 0
    Set-Reg $p 'AllowSearchToUseLocation' 0
    Set-Reg $p 'ConnectedSearchUseWeb' 0
    Set-Reg $p 'DisableWebSearch' 1
}

T 'sys.ceip' 'Privacy' 'Customer Experience Program + feedback prompts off' 'Disables CEIP/SQM data collection and feedback-request popups.' 'Safe' 1 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows' 'CEIPEnable' 0
    Set-Reg 'HKCU:\Software\Microsoft\Siuf\Rules' 'NumberOfSIUFInPeriod' 0
    Set-Reg 'HKCU:\Software\Microsoft\Siuf\Rules' 'PeriodInNanoSeconds' 0
}

T 'sys.appcompat' 'Background' 'App compatibility telemetry off' 'Stops application-inventory, steps recorder and program-compat assistant data collection that scans your installed programs.' 'Safe' 1 {
    $p = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat'
    Set-Reg $p 'AITEnable' 0
    Set-Reg $p 'DisableInventory' 1
    Set-Reg $p 'DisablePCA' 1
}

T 'sys.noreboot' 'Updates' 'No forced restart while you are logged in' 'Windows Update will not reboot your PC in the middle of a match or download.' 'Safe' 1 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' 'NoAutoRebootWithLoggedOnUsers' 1
}

T 'aud.duck' 'Audio' 'Disable audio ducking' 'Windows will not lower game volume when voice chat / calls start.' 'Safe' 1 {
    Set-Reg 'HKCU:\Software\Microsoft\Multimedia\Audio' 'UserDuckingPreference' 3
}

T 'sys.location' 'Privacy' 'Location services off (policy)' 'No background location lookups.' 'Moderate' 3 {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors' 'DisableLocation' 1
}

T 'pri.tasks2' 'Background' 'Disable more maintenance/diagnostic tasks' 'Memory diagnostic events, WinSAT benchmark, power-efficiency analysis, diagnosis and flighting refresh tasks. (Defrag/TRIM task is deliberately left alone.)' 'Safe' 3 {
    foreach ($t in '\Microsoft\Windows\MemoryDiagnostic\ProcessMemoryDiagnosticEvents',
                   '\Microsoft\Windows\MemoryDiagnostic\RunFullMemoryDiagnostic',
                   '\Microsoft\Windows\Maintenance\WinSAT',
                   '\Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem',
                   '\Microsoft\Windows\Diagnosis\Scheduled',
                   '\Microsoft\Windows\Flighting\OneSettings\RefreshCache',
                   '\Microsoft\Windows\Application Experience\PcaPatchDbTask') { Disable-Task $t }
}

T 'def.cloud' 'Security' 'Defender: cloud sample submission + MAPS off' 'Stops automatic sample uploads and cloud lookups (less network chatter). Real-time protection stays ON, but cloud-delivered detections are reduced.' 'Moderate' 3 {
    try {
        $m = Get-MpPreference
        Add-UndoCmd ('Set-MpPreference -SubmitSamplesConsent {0}; Set-MpPreference -MAPSReporting {1}' -f [int]$m.SubmitSamplesConsent, [int]$m.MAPSReporting)
        Set-MpPreference -SubmitSamplesConsent 2
        Set-MpPreference -MAPSReporting 0
    } catch { Log '  ! Defender not available' }
}

# ===================================================================== v1.6 PACK =====================================================================
function Set-IdleValue([string]$path, [string]$name, [uint32]$val) {
    try { $k = Get-Item -LiteralPath $path -ErrorAction Stop } catch { return }
    if ($k.GetValueNames() -notcontains $name) { return }
    $kind = $k.GetValueKind($name).ToString()
    $bytes = [BitConverter]::GetBytes($val)
    if ($kind -eq 'Binary') { Set-Reg $path $name ([byte[]]$bytes) 'Binary' }
    elseif ($kind -eq 'DWord') { Set-Reg $path $name ([BitConverter]::ToInt32($bytes, 0)) 'DWord' }
}

T 'aud.mmcss' 'Audio' 'Audio stack: MMCSS high priority' 'Gives the Windows Audio scheduler task high CPU/GPU priority so Discord and game audio do not crackle or lag when the CPU is at 100%.' 'Safe' 1 {
    $a = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio'
    Set-Reg $a 'Priority' 6
    Set-Reg $a 'GPU Priority' 8
    Set-Reg $a 'Scheduling Category' 'High' 'String'
    Set-Reg $a 'SFIO Priority' 'High' 'String'
}

T 'svc.oem' 'Services' 'OEM bloat: disable vendor analytics/updater services (auto-detected)' 'ASUS, Lenovo, Dell, HP and Razer ship background analytics, "optimizer" and updater services. Only the ones actually installed on this PC are touched. Fan, RGB and hotkey services are NOT touched here (see the Menace-only vendor-suite tweak).' 'Safe' 3 {
    $names = 'AsusAppService', 'ASUSOptimization', 'ASUSSoftwareManager', 'ASUSSystemAnalysis', 'ASUSSystemDiagnosis',
             'LenovoVantageService', 'SUService',
             'DellTechHub', 'SupportAssistAgent', 'DDVCollectorSvcApi', 'DDVDataCollector', 'DDVRulesProcessor', 'DellOptimizer',
             'HPTouchpointAnalyticsService', 'HPAppHelperCap', 'HPDiagsCap', 'HPNetworkCap', 'HPSysInfoCap',
             'Razer Game Scanner Service'
    $hit = 0
    foreach ($s in $names) {
        if (Get-Service -Name $s -ErrorAction SilentlyContinue) { Log "  OEM service found: $s"; Set-Svc $s; $hit++ }
    }
    if ($hit -eq 0) { Log '  no known OEM analytics services on this PC' }
}

T 'svc.oem2' 'Services' 'OEM vendor suites: Armoury Crate / MSI Center / Synapse / Vantage (auto-detected)' 'Stops the heavy vendor control suites (ASUS Armoury Crate, MSI Center, Razer Synapse, Lenovo Vantage). You LOSE fan curves, RGB, macros and performance-mode switching from those apps until you revert. Skipped in laptop mode.' 'Moderate' 4 {
    $names = 'ArmouryCrateService', 'ArmouryCrate.Service', 'MSI Foundation Service', 'MSI_Center_Service', 'Razer Synapse Service', 'RzActionSvc', 'LenovoVantageService'
    $hit = 0
    foreach ($s in $names) {
        if (Get-Service -Name $s -ErrorAction SilentlyContinue) { Log "  vendor suite service found: $s"; Set-Svc $s; $hit++ }
    }
    if ($hit -eq 0) { Log '  no known vendor-suite services on this PC' }
} -NoLaptop

T 'gpu.hdaudio' 'Latency' 'GPU HDMI/DisplayPort audio: stop idle power-down' 'The audio controller on a graphics card can power down when silent and wake with a delay or a DPC spike when sound starts. Sets its idle power timers to "never". Only devices whose driver exposes these keys are changed (existing values only, nothing is created).' 'Moderate' 3 {
    $base = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e96c-e325-11ce-bfc1-08002be10318}'
    $hit = 0
    Get-ChildItem $base -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^\d{4}$' } | ForEach-Object {
        $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
        if ($p.DriverDesc -notmatch 'NVIDIA|AMD|Display Audio|HDMI|DisplayPort') { return }
        $ps = Join-Path $_.PSPath 'PowerSettings'
        if (-not (Test-Path -LiteralPath $ps)) { return }
        Log "  GPU audio: $($p.DriverDesc)"
        Set-IdleValue $ps 'ConservationIdleTime' 4294967295
        Set-IdleValue $ps 'PerformanceIdleTime' 4294967295
        Set-IdleValue $ps 'IdlePowerState' 0
        $hit++
    }
    if ($hit -eq 0) { Log '  no GPU audio device with adjustable idle timers found' }
} -NoLaptop -Reboot

T 'gpu.ulps' 'GPU' 'AMD: disable ULPS (Ultra Low Power State)' 'Stops AMD Radeon cards dropping to ultra-low clocks between frames. Fixes cold-clock stutter in CPU-bound games on some systems. Only changes AMD drivers that expose EnableUlps; does nothing on NVIDIA/Intel.' 'Moderate' 2 {
    $base = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
    $hit = 0
    Get-ChildItem $base -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^\d{4}$' } | ForEach-Object {
        $kp = $_.PSPath
        $k = Get-Item -LiteralPath $kp -ErrorAction SilentlyContinue
        foreach ($n in 'EnableUlps', 'EnableUlps_NA') {
            if ($k -and ($k.GetValueNames() -contains $n)) { Set-Reg $kp $n 0; $hit++ }
        }
    }
    if ($hit -eq 0) { Log '  no AMD driver with ULPS found' }
} -NoLaptop -Reboot

T 'inp.usbhub' 'Latency' 'USB root hubs / controllers: no idle power-down' 'High-polling mice (1000-8000 Hz) and wireless dongles can hitch when a USB hub or controller idles. Disables enhanced power management and idle-in-D3 on USB hubs and host controllers. Desktops only.' 'Moderate' 3 {
    $hit = 0
    Get-PnpDevice -PresentOnly -Class USB -ErrorAction SilentlyContinue | Where-Object {
        $_.InstanceId -like 'USB\ROOT_HUB*' -or $_.FriendlyName -match 'Hub|Host Controller'
    } | ForEach-Object {
        $k = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($_.InstanceId)\Device Parameters"
        if (Test-Path -LiteralPath $k) {
            Set-Reg $k 'EnhancedPowerManagementEnabled' 0
            Set-Reg $k 'AllowIdleIrpInD3' 0
            Set-Reg $k 'SelectiveSuspendEnabled' 0
            $hit++
        }
    }
    Log "  $hit USB device(s) adjusted"
} -NoLaptop -Reboot

T 'cpu.hybrid' 'CPU' 'Intel hybrid CPU: prefer performance cores (P-cores)' 'Sets the Windows thread-scheduling policy to "prefer performant cores" for normal and short-running threads, so game threads stay on P-cores. Applied only on Intel 12th-gen+ / Core Ultra hybrid CPUs, to the Strix plan (or your active plan). AMD X3D chips are not steered here: the AMD chipset driver and Game Bar handle V-Cache; use the core-affinity launcher on the Games tab for manual control.' 'Moderate' 3 {
    if (-not $script:CpuHybrid) { Log '  skipped: this CPU is not an Intel hybrid (P/E-core) design'; return }
    $cpu = '54533251-82be-4824-96c1-47b60b740d00'
    [void](Add-PlanAddon $cpu '93b8b066-19f3-4da0-9988-22d0d0879610' 2)
    [void](Add-PlanAddon $cpu 'bae08b81-2d5e-4688-ad6a-13243356654b' 2)
}

T 'sto.ds' 'Storage' 'DirectStorage / NVMe: no NTFS compression, no encrypted pagefile' 'DirectStorage games stream assets straight from the NVMe; NTFS compression and pagefile encryption add CPU work to that path. Turns both off for NEW files (existing files are untouched). The pagefile setting is only changed if it was on.' 'Safe' 3 {
    foreach ($pair in @(@('disablecompression', 'DisableCompression', 1), @('encryptpagingfile', 'EncryptPagingFile', 0))) {
        $o = fsutil behavior query $pair[0] | Out-String
        if ($o -match ($pair[1] + '\s*=\s*(\d)')) {
            $prev = $Matches[1]
            if ([int]$prev -ne $pair[2]) {
                fsutil behavior set $pair[0] $pair[2] | Out-Null
                Add-UndoCmd ('fsutil behavior set {0} {1}' -f $pair[0], $prev)
                Log "  $($pair[0]): $prev -> $($pair[2])"
            }
        }
    }
}

# ------------------------------------------------------------------ game database
$script:Games = @(
 @{ Name='VALORANT'; Exe='VALORANT-Win64-Shipping.exe'; AC=$true; Launch='(none needed)';
    High='Fullscreen. Multithreaded Rendering ON. Material/Texture/Detail: Medium-High, Shadows OFF, Bloom OFF, Distortion OFF, Vignette OFF, V-Sync OFF, Anti-aliasing MSAA 2x or None, Anisotropic 4x, Improve Clarity OFF. NVIDIA Reflex: On + Boost. FPS cap: unlimited or 3x refresh rate.';
    Mid='Everything Low except Texture Medium. Multithreaded Rendering ON, Shadows/Bloom/Distortion/Vignette OFF, MSAA OFF, Reflex On, uncapped FPS.';
    Low='All Low, resolution 1280x960/1024x768 if needed (stretched), Multithreaded Rendering ON, Cast Shadows OFF, Vignette OFF, cap FPS at 144 to avoid 1% lows dips. Close the browser and Discord overlays.' }
 @{ Name='Counter-Strike 2'; Exe='cs2.exe'; AC=$false; Launch='-novid -high +fps_max 0 -nojoy';
    High='Shadow quality High, Model/Texture High, Shader Medium, Particle Medium, AO Disabled, HDR Performance, Boost Player Contrast ON, MSAA 4x (if GPU is idle) or CMAA2, FSR OFF, Reflex On+Boost, V-Sync OFF, fps_max 0.';
    Mid='Shadow Medium, Model/Texture Medium, Shader Low, Particle Low, AO Disabled, MSAA 2x/CMAA2, Reflex On, 16:9 native resolution.';
    Low='Global shadow Low, Model Low, Texture Low, Shader Low, Particle Low, AO Disabled, Texture filtering Bilinear, FSR Performance or lower resolution (1280x960 stretched), fps_max 0.' }
 @{ Name='Fortnite'; Exe='FortniteClient-Win64-Shipping.exe'; AC=$true; Launch='-USEALLAVAILABLECORES -NOSPLASH';
    High='DirectX 12 + shader cache. 3D resolution 100%. Nanite ON, Lumen OFF (or Low), Virtual Shadow Maps Low/Medium, View distance Far, Textures Medium/High, Effects Low, Post processing Low, Reflex On+Boost, uncapped.';
    Mid='DirectX 12 (or 11 if stutter). Resolution 100%, Nanite OFF, Lumen OFF, Shadows Off/Low, View distance Medium, Textures Medium, Effects Low, Reflex On.';
    Low='Performance Mode (the lowest-quality renderer: huge FPS gain), 3D resolution 75-100%, DX11 if you stutter, everything Low. Cap 60-144 for stable frame times.' }
 @{ Name='Apex Legends'; Exe='r5apex_dx12.exe'; AC=$true; Launch='+fps_max unlimited -novid';
    High='Fullscreen, V-Sync OFF, Adaptive resolution target 0, Texture streaming budget = your VRAM minus 1GB, Anisotropic 4x, AO Disabled, Sun/Spot shadow coverage Low, Spot shadow detail Low, Volumetric lighting Disabled, Dynamic spot shadows OFF, Model detail High, Effects Low, Impact marks Low, Ragdolls Low.';
    Mid='As above but Texture streaming budget Medium, Model detail Medium, Effects Low, Anisotropic 2x, Ambient occlusion Disabled.';
    Low='Everything Low/Disabled, Texture streaming budget Low-Medium (to fit VRAM), Model detail Low, Resolution scale 80-90% if required. Use DX11 (r5apex.exe) on older GPUs.' }
 @{ Name='Call of Duty: Warzone'; Exe='cod.exe'; AC=$true; Launch='(none)';
    High='Render resolution 100%, DLSS/FSR Quality, Texture Resolution Normal/High, Shadow Map Resolution Low, Cache Spot Shadows OFF, Particle Quality Low, Tessellation OFF, Ambient Occlusion OFF, Depth of Field OFF, World Motion Blur OFF, Reflex On+Boost, uncapped. Let shaders fully compile on first launch.';
    Mid='DLSS/FSR Balanced, Texture Normal, Shadow Low, Spot Cache OFF, Particles Low, Tessellation OFF, AO OFF.';
    Low='FSR Performance, Render resolution 80-90%, Texture Low, Shadow Low, Particles Low, everything else OFF/Low. Make sure the game is on an SSD.' }
 @{ Name='GTA V / GTA Online'; Exe='GTA5.exe'; AC=$true; Launch='-notablet -nobenchmark';
    High='DirectX 11, MSAA OFF + FXAA ON (MSAA is the biggest FPS killer), Reflection MSAA OFF, Grass Normal, Shadows High, Long Shadows OFF, High Res Shadows OFF, Population density ~70%, V-Sync OFF.';
    Mid='FXAA only, Grass Normal, Shadows Normal/High, Post FX Normal, Reflection Quality High, Population density 50-60%.';
    Low='All Normal/Low, MSAA OFF, FXAA OFF, Grass Low, Shadows Normal, Particle Normal, Population density 30-40%, Distance scaling lowered.' }
 @{ Name='Cyberpunk 2077'; Exe='Cyberpunk2077.exe'; AC=$false; Launch='(none)';
    High='DLSS/FSR Quality (+ Frame Generation if supported), Ray Tracing OFF or RT Reflections only, Screen Space Reflections Medium, Volumetric Fog Medium, Volumetric Clouds Medium, Crowd Density Medium, Cascaded Shadows Medium, Contact Shadows OFF, Color Precision Medium, Motion Blur OFF.';
    Mid='DLSS/FSR Balanced, RT OFF, Volumetrics Low/Medium, Crowd Medium, SSR Medium, Local Shadow Mesh Medium, Contact Shadows OFF, Colour Precision Medium.';
    Low='FSR Performance, everything Low, Crowd Density Low, Volumetric Fog/Clouds Low, SSR Low, Contact Shadows OFF, resolution scaling to taste.' }
 @{ Name='Minecraft (Java)'; Exe='javaw.exe'; AC=$false; Launch='JVM: -Xms4G -Xmx4G (match min=max) with Java 21';
    High='Install Fabric + Sodium + Lithium + Iris (shaders optional) + EntityCulling. Render distance 12-16, Simulation 8-10, Smooth lighting ON, Max FPS Unlimited, V-Sync OFF.';
    Mid='Sodium + Lithium, Render distance 10-12, Simulation 6-8, Clouds OFF, Particles Decreased, Entity distance 75%.';
    Low='Sodium + Lithium + EntityCulling + FerriteCore, Render distance 6-8, Simulation 5-6, Graphics Fast, Smooth lighting OFF, Particles Minimal, Biome blend 1, allocate only 2-3 GB.' }
 @{ Name='League of Legends'; Exe='League of Legends.exe'; AC=$true; Launch='(none)';
    High='Borderless/Fullscreen, Character/Environment High, Shadows Low/Off, Effects Medium, Frame rate: uncapped or 240, Hide Eye Candy ON, V-Sync OFF, Anti-aliasing OFF.';
    Mid='Character/Environment Medium, Shadows OFF, Effects Low, Hide Eye Candy ON, FPS cap 144.';
    Low='Very Low everything, Shadows OFF, Hide Eye Candy ON, FPS cap 60-144, close the Riot Client UI after queueing.' }
 @{ Name='Overwatch 2'; Exe='Overwatch.exe'; AC=$false; Launch='(none)';
    High='Fullscreen, Render scale 100% (or DLSS/FSR Quality), Reflex On+Boost, Texture Medium/High, Shadow Low, Model Low, Effects Low, Lighting Low, Local Fog Low, Dynamic Reflections OFF, AO OFF, Refraction Low, Screenshot quality 1x, Anti-aliasing SMAA Low, uncapped FPS.';
    Mid='Render scale 100%, Texture Medium, Shadow Low, Effects/Lighting/Fog Low, Reflections OFF, AO OFF, FSR 1 Quality if needed.';
    Low='Render scale 75-85% (FSR 1), Texture Low, everything Low/OFF, Anti-aliasing OFF.' }
 @{ Name='Rocket League'; Exe='RocketLeague.exe'; AC=$true; Launch='(none)';
    High='Fullscreen, Render Quality High Performance, Render Detail Performance, Texture Detail Performance, World Detail Performance, Anti-aliasing FXAA/Off, AO OFF, Bloom OFF, Lens Flares OFF, Motion Blur OFF, Weather FX OFF, uncapped or 250.';
    Mid='Same as High-End; keep Render Quality High Performance, Texture Detail Quality only if GPU has headroom.';
    Low='Everything Performance/OFF, Transparent goalposts ON, Fixed 60 or 144 cap.' }
 @{ Name='Rainbow Six Siege'; Exe='RainbowSix_Vulkan.exe'; AC=$true; Launch='Use the Vulkan renderer on modern GPUs; DX11 (RainbowSix.exe) on older ones';
    High='Fullscreen, V-Sync OFF, Reflex On, Texture Medium/High, LOD Medium, Shading Medium, Shadow Medium, Reflection Low, AO OFF, Lens Effects OFF, Motion Blur OFF, DoF OFF, TAA with Sharpness 50-70, uncapped FPS.';
    Mid='Texture Medium, LOD Low/Medium, Shading Low, Shadow Low, Reflection Low, AO OFF, T-AA or FXAA, DLSS/FSR Balanced if offered.';
    Low='Everything Low, resolution scale 70-85% (T-AA), Shadows Low, AO OFF, cap FPS at 60/144 for steady frame times.' }
 @{ Name='PUBG: Battlegrounds'; Exe='TslGame.exe'; AC=$true; Launch='-USEALLAVAILABLECORES -high';
    High='Fullscreen, DX11 (DX12 only on newest GPUs), Screen scale 100, Anti-aliasing Medium, Post-processing Very Low, Shadows Very Low, Textures Medium/High, Effects Very Low, Foliage Very Low, View distance Medium, V-Sync OFF, Motion blur OFF, uncapped.';
    Mid='Screen scale 100, AA Low, Post-processing/Shadows/Effects/Foliage Very Low, Textures Medium, View distance Low/Medium.';
    Low='Screen scale 80-90, everything Very Low, Textures Low, View distance Low, install on an SSD (huge loading difference).' }
 @{ Name='Marvel Rivals'; Exe='Marvel-Win64-Shipping.exe'; AC=$true; Launch='(none)';
    High='DX11 or DX12 (test both), DLSS/FSR Quality, Frame Generation only if base FPS > 60, Reflex On+Boost, Global Illumination Low/Off, Reflections Low, Shadows Low, Effects Low, Post-processing Low, Textures Medium/High, Motion blur OFF.';
    Mid='DLSS/FSR Balanced, GI Off, Reflections Off, Shadows Low, Effects Low, Textures Medium.';
    Low='Rendering scale 70-80% with FSR, Low preset everything, Shadows and Reflections OFF, Textures Low. Cap at 60 or 100 for even pacing.' }
 @{ Name='Dota 2'; Exe='dota2.exe'; AC=$false; Launch='-novid -high +fps_max 0 -dx11 (try -vulkan on weak GPUs)';
    High='Vulkan or DX11, Render quality 100%, Texture Medium/High, Shadow Medium, Effects Medium, Ambient Occlusion OFF, FXAA/None, V-Sync OFF.';
    Mid='DX11, Texture Medium, Shadow Low, Effects Low, AO OFF, Render quality 100%.';
    Low='Vulkan, Render quality 70-80%, everything Low/OFF, Shadow OFF, FXAA OFF.' }
 @{ Name='Red Dead Redemption 2'; Exe='RDR2.exe'; AC=$false; Launch='(none)';
    High='Vulkan if CPU-bound, DX12 otherwise. Shadow Quality Medium/High, Volumetrics Medium, Water Physics Medium, Tree Tessellation OFF, MSAA OFF, TAA Medium, Reflection Medium, Far Shadow Medium, Grass LOD Medium, Texture High (VRAM allowing). DLSS/FSR Quality.';
    Mid='Shadows Medium, Volumetrics Low, Water Physics Low, Tree Tessellation OFF, MSAA OFF, TAA Low, Reflection Low, Grass LOD Low, FSR Quality.';
    Low='Use the Low preset, Shadows Low, Volumetrics OFF/Low, MSAA OFF, TAA OFF, Texture Medium, resolution scale 75-85% with FSR.' }
 @{ Name='Baldur''s Gate 3'; Exe='bg3_dx11.exe'; AC=$false; Launch='Use DX11 (bg3_dx11.exe) for stability; Vulkan (bg3.exe) can be faster on some GPUs';
    High='DLSS/FSR Quality, Shadow Quality Medium, Cloud Shadows OFF, Fog Low/Medium, Model Quality High, Detail Distance Medium, Texture High, Animation Level of Detail Medium, V-Sync OFF.';
    Mid='FSR Quality, Shadow Low/Medium, Cloud Shadows OFF, Fog Low, Model Medium, Texture Medium.';
    Low='FSR Performance, Shadow Low, Cloud Shadows OFF, Fog Low, Model Low, Texture Low, Detail Distance Low (Act 3 is CPU heavy).' }
 @{ Name='Roblox'; Exe='RobloxPlayerBeta.exe'; AC=$true; Launch='(none)';
    High='Graphics Quality Manual 8-10, FPS unlock (uncapped via settings.json or Bloxstrap), Vulkan/DX11, Shadows ON only if GPU is idle.';
    Mid='Graphics Quality 5-7, uncapped FPS, DX11.';
    Low='Graphics Quality 1-3, Disable Shadows, DX11 or Vulkan, close the browser tabs, cap FPS at 60 if it stutters.' }
 @{ Name='Elden Ring'; Exe='eldenring.exe'; AC=$true; Launch='(Use the EAC-launch only for online; offline play uses fewer resources)';
    High='Fullscreen, Quality Preset Maximum/High, Shadow Quality Medium, Volumetric Quality Medium, SSAO Medium, Depth of Field OFF, Motion Blur OFF, Ray tracing OFF. Frame rate is locked at 60: use a 60 Hz or VRR display and a stable frametime.';
    Mid='Quality High, Shadow Medium, Lighting Medium, Volumetric Low, SSAO Medium, DoF OFF, Motion Blur OFF.';
    Low='Quality Low/Medium, Shadow Low, Volumetric Low, SSAO OFF, Lighting Low, Effects Medium, resolution scale if available, keep the game on an SSD.' }
 @{ Name='Custom game (any .exe)'; Exe=''; AC=$false; Launch='-';
    High='Pick the game .exe below. Strix will set: High-performance GPU preference, fullscreen-optimization OFF for that exe, and (non anti-cheat) High CPU priority. All reversible with Revert profile.';
    Mid='Universal advice: turn V-Sync OFF, use DLSS/FSR Quality, lower Shadows, Volumetrics and Ambient Occlusion first (biggest FPS for least visual loss), keep Textures at the highest your VRAM allows.';
    Low='Universal advice: lower resolution scale / use FSR Performance, everything Low, Shadows + Volumetrics + Reflections OFF, cap FPS slightly under refresh rate for stable frame times.' }
)

function Apply-GameProfile([string]$path, [bool]$ac, [bool]$cfgOff = $false) {
    $exe = [IO.Path]::GetFileName($path)
    $id  = 'game.' + $exe.ToLower()
    if (Test-Applied $id) { Restore-Records $id }
    $script:Rec = New-Object System.Collections.ArrayList
    Set-Reg 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences' $path 'GpuPreference=2;' 'String'
    Set-Reg 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers' $path '~ DISABLEDXMAXIMIZEDWINDOWEDMODE' 'String'
    if (-not $ac) {
        Set-Reg "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\$exe\PerfOptions" 'CpuPriorityClass' 3
    }
    if ($cfgOff -and -not $ac) {
        try {
            $cur = Get-ProcessMitigation -Name $exe -ErrorAction Stop
            if ([string]$cur.CFG.Enable -ne 'OFF') {
                Set-ProcessMitigation -Name $exe -Disable CFG -ErrorAction Stop
                Add-UndoCmd "Set-ProcessMitigation -Name '$exe' -Remove -Disable CFG"
                Log "  Control Flow Guard disabled for $exe only (global security untouched)"
            }
        } catch { Log "  ! could not change CFG mitigation: $($_.Exception.Message)" }
    }
    Save-Rec $id
    Log "Game profile applied: $exe (GPU preference high-performance, fullscreen-optimizations off$(if(-not $ac){', CPU priority High'}))"
}

# ------------------------------------------------------------------ actions
function New-RestorePoint {
    if ($script:RPDone) { return }
    Log 'Creating system restore point...'
    Pump
    try {
        Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction Stop
        $k = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore'
        $old = (Get-ItemProperty $k -ErrorAction SilentlyContinue).SystemRestorePointCreationFrequency
        New-ItemProperty $k -Name SystemRestorePointCreationFrequency -Value 0 -PropertyType DWord -Force | Out-Null
        Checkpoint-Computer -Description 'Strix Tweaks 1.6' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
        if ($null -eq $old) { Remove-ItemProperty $k -Name SystemRestorePointCreationFrequency -ErrorAction SilentlyContinue }
        else { Set-ItemProperty $k -Name SystemRestorePointCreationFrequency -Value $old }
        Log 'Restore point created.'
    } catch { Log "Restore point could not be created (Strix undo data still works): $($_.Exception.Message)" }
    $script:RPDone = $true
}

function Refresh-Status {
    foreach ($t in $script:Tweaks) { $t.Status = if (Test-Applied $t.Id) { 'APPLIED' } else { '' } }
}

function Apply-Tweak($t) {
    if (Test-Applied $t.Id) { Log "= $($t.Name) (already applied)"; return }
    Log "+ $($t.Name)"
    $script:Rec = New-Object System.Collections.ArrayList
    try { & $t.Apply } catch { Log "  ! $($_.Exception.Message)" }
    if ($script:Rec.Count -gt 0) { Save-Rec $t.Id; $t.Status = 'APPLIED' } else { Log '  (nothing changed)' }
    Pump
}

function Revert-Tweak($t) {
    if (-not (Test-Applied $t.Id)) { return }
    Log "- Reverting: $($t.Name)"
    Restore-Records $t.Id
    $t.Status = ''
    Pump
}

function Run-Apply($list) {
    if ($list.Count -eq 0) { [void][System.Windows.MessageBox]::Show('Nothing selected.', 'Strix Tweaks'); return }
    $script:Window.IsEnabled = $false
    try {
        New-RestorePoint
        $reboot = $false
        foreach ($t in $list) { Apply-Tweak $t; if ($t.Reboot) { $reboot = $true } }
        Log 'All done.'
        if ($reboot) { Log 'REBOOT recommended for some of these tweaks to take effect.' }
    } finally { $script:Window.IsEnabled = $true }
    $msg = 'Finished. Some changes (graphics, kernel, services) need a reboot.'
    [void][System.Windows.MessageBox]::Show($msg, 'Strix Tweaks')
}

function Run-Revert($list) {
    $script:Window.IsEnabled = $false
    try { foreach ($t in $list) { Revert-Tweak $t }; Log 'Revert complete.' } finally { $script:Window.IsEnabled = $true }
    [void][System.Windows.MessageBox]::Show('Reverted. Reboot to fully return to the previous state.', 'Strix Tweaks')
}

function Select-Preset([int]$maxTier) {
    $lap = [bool]$script:ChkLaptop.IsChecked
    foreach ($t in $script:Tweaks) {
        $t.Selected = (($t.Tier -le $maxTier) -and -not ($lap -and $t.NoLaptop))
    }
}

# ------------------------------------------------------------------ v1.6: profiles + unattended (CLI) mode
function Read-StrixProfile([string]$path) {
    try {
        $o = Get-Content -LiteralPath $path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    } catch { Log "Profile could not be read: $($_.Exception.Message)"; return $null }
    if ($o.app -ne 'StrixTweaks' -or -not $o.tweaks) { Log 'Not a valid Strix profile file.'; return $null }
    return $o
}

if ($script:Cli) {
    if ($List) {
        foreach ($t in $script:Tweaks) {
            Write-Output ('{0,-14} {1,-9} {2,-9} {3,-13} {4}' -f $t.Id, $t.Category, $t.Risk, $t.Level, $t.Name)
        }
        exit 0
    }

    Log "Strix Tweaks $($script:Version) - unattended mode"
    if ($env:USERNAME -like '*$') {
        Log 'WARNING: running as SYSTEM. Per-user (HKCU) tweaks go to the SYSTEM profile, not to a signed-in user. For deployment, run elevated inside the target user session.'
    }

    if ($Revert) {
        $n = 0
        foreach ($t in $script:Tweaks) { if (Test-Applied $t.Id) { Revert-Tweak $t; $n++ } }
        foreach ($f in @(Get-ChildItem -LiteralPath $script:UndoDir -Filter 'game.*.json' -ErrorAction SilentlyContinue)) {
            Log "- Reverting game profile $($f.BaseName)"; Restore-Records $f.BaseName; $n++
        }
        Log "Revert complete ($n item(s)). Reboot to fully return to the previous state."
        if ($n -gt 0) { exit 3010 } else { exit 0 }
    }

    $picked = @()
    $label = ''
    if ($ProfilePath) {
        $p = Read-StrixProfile $ProfilePath
        if (-not $p) { exit 2 }
        $ids = @($p.tweaks)
        foreach ($id in $ids) {
            if (-not ($script:Tweaks | Where-Object { $_.Id -eq $id })) { Log "  unknown tweak id in profile (ignored): $id" }
        }
        $picked = @($script:Tweaks | Where-Object { $ids -contains $_.Id })
        $label = "profile $ProfilePath"
    } else {
        $max = @{ High = 1; Mid = 2; Low = 3; Menace = 4 }[$Preset]
        $picked = @($script:Tweaks | Where-Object { $_.Tier -le $max })
        $label = "preset $Preset"
    }
    $picked = @($picked | Where-Object { -not ($script:IsLaptop -and $_.NoLaptop) })

    $risky = @($picked | Where-Object { $_.Risk -eq 'Risky' })
    if ($risky.Count -gt 0 -and -not $AcceptRisk) {
        Log "Refusing to run: $($risky.Count) tweak(s) in $label are marked RISKY (security/compat trade-offs):"
        foreach ($r in $risky) { Log "    - $($r.Id): $($r.Name)" }
        Log 'Re-run with -AcceptRisk if you really want them.'
        exit 2
    }

    $guard = if ($script:Hybrid) { if ($script:HybridSafe) { 'ON' } else { 'OFF (bypassed)' } } else { 'n/a' }
    Log "Applying $($picked.Count) tweak(s) from $label. Laptop mode: $($script:IsLaptop). Optimus/MUX safety: $guard."
    if (-not $NoRestorePoint) { New-RestorePoint }
    $reboot = $false
    foreach ($t in $picked) {
        Apply-Tweak $t
        if ($t.Reboot -and (Test-Applied $t.Id)) { $reboot = $true }
    }
    Log 'Done.'
    if ($reboot) { Log 'A reboot is required for some changes (exit code 3010).'; exit 3010 }
    exit 0
}

# ------------------------------------------------------------------ UI
[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="STRIX TWEAKS 1.6" Width="1200" Height="880" MinWidth="960" MinHeight="640"
        Background="#0E0F14" WindowStartupLocation="CenterScreen" FontFamily="Segoe UI" FontSize="13">
  <Window.Resources>
    <Style x:Key="Btn" TargetType="Button">
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="Background" Value="#23263A"/>
      <Setter Property="Padding" Value="14,8"/>
      <Setter Property="Margin" Value="0,0,8,8"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="b" Background="{TemplateBinding Background}" CornerRadius="7" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="b" Property="Opacity" Value="0.82"/></Trigger>
              <Trigger Property="IsEnabled" Value="False"><Setter TargetName="b" Property="Opacity" Value="0.4"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
  </Window.Resources>
  <Grid Margin="16" RenderTransformOrigin="0.5,0.5">
    <Grid.RenderTransform><TranslateTransform x:Name="RootShift"/></Grid.RenderTransform>
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
      <RowDefinition Height="140"/>
    </Grid.RowDefinitions>

    <Grid Grid.Row="0" Margin="0,0,0,10">
      <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
      <StackPanel>
        <StackPanel Orientation="Horizontal">
          <TextBlock Text="STRIX" FontSize="28" FontWeight="Black" Foreground="#8B6CFF"/>
          <TextBlock Text=" TWEAKS " FontSize="28" FontWeight="Black" Foreground="White"/>
          <TextBlock Text="1.6" FontSize="28" FontWeight="Black" Foreground="#FF5C5C"/>
        </StackPanel>
        <TextBlock x:Name="HwText" Foreground="#9AA0B8" Margin="0,2,0,0" TextWrapping="Wrap"/>
        <Border Height="2" Margin="0,8,0,0" CornerRadius="1" HorizontalAlignment="Stretch">
          <Border.Background>
            <LinearGradientBrush StartPoint="0,0" EndPoint="0.5,0" SpreadMethod="Repeat">
              <LinearGradientBrush.RelativeTransform><TranslateTransform x:Name="AccentShift"/></LinearGradientBrush.RelativeTransform>
              <GradientStop Color="#8B6CFF" Offset="0"/><GradientStop Color="#35E0FF" Offset="0.35"/>
              <GradientStop Color="#FF5C5C" Offset="0.7"/><GradientStop Color="#8B6CFF" Offset="1"/>
            </LinearGradientBrush>
          </Border.Background>
        </Border>
        <WrapPanel Margin="0,8,0,0">
          <TextBlock x:Name="StTimer" FontFamily="Consolas" Foreground="#9AA0B8" Margin="0,0,22,0" ToolTip="Current Windows system timer resolution (lower = smoother frame pacing). 15.625 ms is the default."/>
          <TextBlock x:Name="StVbs" FontFamily="Consolas" Foreground="#9AA0B8" Margin="0,0,22,0" ToolTip="Virtualization-Based Security / Memory Integrity state"/>
          <TextBlock x:Name="StPlan" FontFamily="Consolas" Foreground="#9AA0B8" Margin="0,0,22,0" ToolTip="Active Windows power plan"/>
          <TextBlock x:Name="StGpu" FontFamily="Consolas" Foreground="#9AA0B8" Margin="0,0,22,0" ToolTip="Hardware-accelerated GPU scheduling + hybrid-graphics guard"/>
          <TextBlock x:Name="StApplied" FontFamily="Consolas" Foreground="#9AA0B8" ToolTip="Number of Strix change sets currently applied"/>
        </WrapPanel>
      </StackPanel>
      <StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center">
        <Button x:Name="NavTweaks" Content="Tweaks" Style="{StaticResource Btn}" Background="#8B6CFF"/>
        <Button x:Name="NavGames" Content="Games" Style="{StaticResource Btn}"/>
        <Button x:Name="NavInfo" Content="Tools" Style="{StaticResource Btn}"/>
      </StackPanel>
    </Grid>

    <WrapPanel Grid.Row="1" Margin="0,0,0,6">
      <Button x:Name="BtnHigh" Content="High-End PC / Laptop" Style="{StaticResource Btn}" Background="#2D7A4F"/>
      <Button x:Name="BtnMid" Content="Mid-Range PC / Laptop" Style="{StaticResource Btn}" Background="#2F62B5"/>
      <Button x:Name="BtnLow" Content="Low-End PC / Laptop" Style="{StaticResource Btn}" Background="#B07A1F"/>
      <Button x:Name="BtnMenace" Content="MENACE MODE" Style="{StaticResource Btn}" Background="#D6313B"/>
      <Button x:Name="BtnAuto" Content="Auto-detect" Style="{StaticResource Btn}" Background="#1F8E96" ToolTip="Pick the preset that fits this machine"/>
      <CheckBox x:Name="ChkLaptop" Content="I am on a laptop (skip battery-hungry tweaks)" Foreground="#C9CEE0" VerticalAlignment="Center" Margin="12,0,12,8"/>
      <CheckBox x:Name="ChkHybrid" Content="Optimus/MUX safety (skip MPO on hybrid-graphics laptops)" Foreground="#C9CEE0" VerticalAlignment="Center" Margin="0,0,12,8"/>
      <ComboBox x:Name="CatBox" Width="150" Height="30" Margin="0,0,8,8" VerticalContentAlignment="Center"/>
      <ComboBox x:Name="RiskBox" Width="140" Height="30" Margin="0,0,8,8" VerticalContentAlignment="Center"/>
      <TextBox x:Name="SearchBox" Width="200" Height="30" Margin="0,0,0,8" Background="#151720" Foreground="White" BorderBrush="#2A2E45" Padding="6,4" ToolTip="Search tweaks"/>
    </WrapPanel>

    <Grid Grid.Row="2">
      <!-- TWEAKS PAGE -->
      <Grid x:Name="PageTweaks">
        <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <DataGrid x:Name="TweakGrid" AutoGenerateColumns="False" CanUserAddRows="False" HeadersVisibility="Column"
                  GridLinesVisibility="None" Background="#151720" RowBackground="#151720" AlternatingRowBackground="#191B26"
                  Foreground="#E6E8F0" BorderThickness="0" SelectionMode="Single" RowHeight="30" CanUserResizeRows="False">
          <DataGrid.ColumnHeaderStyle>
            <Style TargetType="DataGridColumnHeader">
              <Setter Property="Background" Value="#1D2030"/><Setter Property="Foreground" Value="#9AA0B8"/>
              <Setter Property="Padding" Value="8,6"/><Setter Property="BorderThickness" Value="0"/>
            </Style>
          </DataGrid.ColumnHeaderStyle>
          <DataGrid.Columns>
            <DataGridTemplateColumn Width="40">
              <DataGridTemplateColumn.CellTemplate>
                <DataTemplate>
                  <CheckBox IsChecked="{Binding Selected, UpdateSourceTrigger=PropertyChanged}" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </DataTemplate>
              </DataGridTemplateColumn.CellTemplate>
            </DataGridTemplateColumn>
            <DataGridTextColumn Header="Category" Binding="{Binding Category}" Width="100" IsReadOnly="True"/>
            <DataGridTextColumn Header="Tweak" Binding="{Binding Name}" Width="*" IsReadOnly="True"/>
            <DataGridTextColumn Header="Risk" Binding="{Binding Risk}" Width="80" IsReadOnly="True">
              <DataGridTextColumn.ElementStyle>
                <Style TargetType="TextBlock">
                  <Style.Triggers>
                    <DataTrigger Binding="{Binding Risk}" Value="Safe"><Setter Property="Foreground" Value="#5CE08A"/></DataTrigger>
                    <DataTrigger Binding="{Binding Risk}" Value="Moderate"><Setter Property="Foreground" Value="#FFC857"/></DataTrigger>
                    <DataTrigger Binding="{Binding Risk}" Value="Risky"><Setter Property="Foreground" Value="#FF5C5C"/></DataTrigger>
                  </Style.Triggers>
                </Style>
              </DataGridTextColumn.ElementStyle>
            </DataGridTextColumn>
            <DataGridTextColumn Header="In preset" Binding="{Binding Level}" Width="105" IsReadOnly="True"/>
            <DataGridTextColumn Header="Status" Binding="{Binding Status}" Width="85" IsReadOnly="True">
              <DataGridTextColumn.ElementStyle>
                <Style TargetType="TextBlock"><Setter Property="Foreground" Value="#8B6CFF"/><Setter Property="FontWeight" Value="Bold"/></Style>
              </DataGridTextColumn.ElementStyle>
            </DataGridTextColumn>
          </DataGrid.Columns>
        </DataGrid>
        <Border Grid.Row="1" Background="#151720" Padding="10" Margin="0,8,0,8" MinHeight="46">
          <TextBlock x:Name="DescText" Foreground="#C9CEE0" TextWrapping="Wrap" Text="Click a tweak to read what it does. Pick a preset, review the ticks, then press APPLY."/>
        </Border>
        <WrapPanel Grid.Row="2">
          <Button x:Name="BtnApply" Content="APPLY SELECTED" Style="{StaticResource Btn}" Background="#8B6CFF"/>
          <Button x:Name="BtnRevert" Content="Revert selected" Style="{StaticResource Btn}"/>
          <Button x:Name="BtnRevertAll" Content="REVERT EVERYTHING" Style="{StaticResource Btn}" Background="#7A2A30"/>
          <Button x:Name="BtnNone" Content="Select none" Style="{StaticResource Btn}"/>
          <Button x:Name="BtnDiff" Content="View applied changes" Style="{StaticResource Btn}" Background="#1F8E96"/>
          <Button x:Name="BtnExport" Content="Export profile (.strix)" Style="{StaticResource Btn}"/>
          <Button x:Name="BtnImport" Content="Import profile" Style="{StaticResource Btn}"/>
        </WrapPanel>
      </Grid>

      <!-- GAMES PAGE -->
      <Grid x:Name="PageGames" Visibility="Collapsed">
        <Grid.ColumnDefinitions><ColumnDefinition Width="270"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
        <ListBox x:Name="GameList" Background="#151720" Foreground="White" BorderThickness="0" Margin="0,0,10,0" FontSize="14"/>
        <Grid Grid.Column="1">
          <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
          <TextBox x:Name="GameText" IsReadOnly="True" TextWrapping="Wrap" VerticalScrollBarVisibility="Auto"
                   Background="#151720" Foreground="#E6E8F0" BorderThickness="0" Padding="14" FontSize="13.5"/>
          <WrapPanel Grid.Row="1" Margin="0,8,0,0">
            <Button x:Name="BtnGameApply" Content="Locate game .exe + apply profile" Style="{StaticResource Btn}" Background="#8B6CFF"/>
            <Button x:Name="BtnGameRevert" Content="Revert all game profiles" Style="{StaticResource Btn}"/>
            <Button x:Name="BtnGameScan" Content="Auto-detect installed games" Style="{StaticResource Btn}" Background="#1F8E96"/>
            <Button x:Name="BtnAffinity" Content="Core-affinity launcher" Style="{StaticResource Btn}"/>
            <CheckBox x:Name="ChkCfg" Content="Also turn off Control Flow Guard for this game only (not for anti-cheat games)" Foreground="#C9CEE0" VerticalAlignment="Center" Margin="8,0,0,8"/>
          </WrapPanel>
        </Grid>
      </Grid>

      <!-- INFO PAGE -->
      <ScrollViewer x:Name="PageInfo" Visibility="Collapsed" VerticalScrollBarVisibility="Auto">
        <StackPanel Margin="0,0,10,0">
          <Border Background="#151720" Padding="12" Margin="0,0,0,10" CornerRadius="8">
            <StackPanel>
              <TextBlock Text="LATENCY CHECK  (before / after)" Foreground="#35E0FF" FontWeight="Bold" Margin="0,0,0,6"/>
              <TextBox x:Name="LatText" IsReadOnly="True" FontFamily="Consolas" Background="#0A0B10" Foreground="#E6E8F0" BorderThickness="0" Padding="10" Height="210" TextWrapping="NoWrap" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto"/>
              <WrapPanel Margin="0,8,0,0">
                <Button x:Name="BtnLat" Content="Run latency check" Style="{StaticResource Btn}" Background="#1F8E96"/>
                <Button x:Name="BtnLatBase" Content="Save current as BEFORE" Style="{StaticResource Btn}"/>
                <Button x:Name="BtnLatReset" Content="Clear baseline" Style="{StaticResource Btn}"/>
                <Button x:Name="BtnForceTimer" Content="Force 0.5 ms timer (while Strix is open)" Style="{StaticResource Btn}" Background="#8B6CFF"/>
              </WrapPanel>
            </StackPanel>
          </Border>
          <Border Background="#151720" Padding="12" Margin="0,0,0,10" CornerRadius="8">
            <StackPanel>
              <TextBlock Text="GRAPHICS &amp; SYSTEM MAINTENANCE" Foreground="#35E0FF" FontWeight="Bold" Margin="0,0,0,8"/>
              <WrapPanel>
                <Button x:Name="BtnShaderDx" Content="Purge DirectX shader cache" Style="{StaticResource Btn}" Background="#2F62B5"/>
                <Button x:Name="BtnShaderGpu" Content="Purge NVIDIA / AMD shader cache" Style="{StaticResource Btn}" Background="#2F62B5"/>
                <Button x:Name="BtnTemp" Content="Clean temp files (one-way)" Style="{StaticResource Btn}" Background="#2F62B5"/>
                <Button x:Name="BtnRam" Content="Free RAM now" Style="{StaticResource Btn}" Background="#2F62B5"/>
                <Button x:Name="BtnTrim" Content="SSD re-TRIM" Style="{StaticResource Btn}" Background="#2F62B5"/>
                <Button x:Name="BtnDns" Content="Flush DNS" Style="{StaticResource Btn}" Background="#2F62B5"/>
                <Button x:Name="BtnNet" Content="Reset network stack" Style="{StaticResource Btn}" Background="#2F62B5"/>
              </WrapPanel>
            </StackPanel>
          </Border>
          <Border Background="#151720" Padding="12" Margin="0,0,0,10" CornerRadius="8">
            <StackPanel>
              <TextBlock Text="SYSTEM" Foreground="#35E0FF" FontWeight="Bold" Margin="0,0,0,8"/>
              <WrapPanel>
                <Button x:Name="BtnRP" Content="Create restore point now" Style="{StaticResource Btn}"/>
                <Button x:Name="BtnFolder" Content="Open Strix data/log folder" Style="{StaticResource Btn}"/>
                <Button x:Name="BtnStartup" Content="Startup apps" Style="{StaticResource Btn}"/>
                <Button x:Name="BtnGfx" Content="Windows graphics settings" Style="{StaticResource Btn}"/>
                <Button x:Name="BtnSec" Content="Windows Security" Style="{StaticResource Btn}"/>
              </WrapPanel>
            </StackPanel>
          </Border>
          <TextBox x:Name="InfoText" IsReadOnly="True" TextWrapping="Wrap" Background="#151720" Foreground="#E6E8F0" BorderThickness="0" Padding="14" MinHeight="420"/>
        </StackPanel>
      </ScrollViewer>
    </Grid>

    <TextBox x:Name="LogBox" Grid.Row="3" IsReadOnly="True" Background="#0A0B10" Foreground="#8FE0A8" FontFamily="Consolas"
             BorderBrush="#1D2030" VerticalScrollBarVisibility="Auto" TextWrapping="Wrap" Margin="0,8,0,0" Padding="8"/>
  </Grid>
</Window>
'@

$reader = New-Object System.Xml.XmlNodeReader $xaml
$script:Window = [Windows.Markup.XamlReader]::Load($reader)
foreach ($n in 'HwText','NavTweaks','NavGames','NavInfo','BtnHigh','BtnMid','BtnLow','BtnMenace','ChkLaptop','SearchBox',
               'PageTweaks','PageGames','PageInfo','TweakGrid','DescText','BtnApply','BtnRevert','BtnRevertAll','BtnNone',
               'GameList','GameText','BtnGameApply','BtnGameRevert','InfoText','BtnRP','BtnTemp','BtnFolder','LogBox',
               'RootShift','AccentShift','BtnAuto','CatBox','BtnRam','BtnTrim','BtnDns','BtnStartup','BtnGfx','BtnSec',
               'StTimer','StVbs','StPlan','StGpu','StApplied','RiskBox','ChkHybrid','BtnExport','BtnImport','BtnDiff','BtnGameScan','ChkCfg','BtnAffinity',
               'LatText','BtnLat','BtnLatBase','BtnLatReset','BtnForceTimer','BtnShaderDx','BtnShaderGpu','BtnNet') {
    Set-Variable -Name "ui_$n" -Value $script:Window.FindName($n) -Scope Script
}
$script:LogBox     = $script:ui_LogBox
$script:ChkLaptop  = $script:ui_ChkLaptop
$script:ChkLaptop.IsChecked = $script:IsLaptop

$winName = if ($script:Build -ge 22000) { "Windows 11 (build $($script:Build))" } else { "Windows build $($script:Build) - Strix targets Windows 11" }
$script:ui_HwText.Text = "$winName  |  $($cpuInfo.Name.Trim()) ($($script:Cores) cores)  |  $($script:RamGB) GB RAM  |  $($script:GpuName)  |  $(if($script:IsLaptop){'Laptop'}else{'Desktop'})  |  Suggested preset: $($script:Suggest)"

# --- tweaks grid
Refresh-Status
$script:ui_TweakGrid.ItemsSource = $script:Tweaks
$script:View = [System.Windows.Data.CollectionViewSource]::GetDefaultView($script:Tweaks)
$script:View.Filter = [Predicate[object]]{
    param($o)
    $q = $script:SearchText
    if ($script:CatFilter -and $o.Category -ne $script:CatFilter) { return $false }
    if ($script:RiskFilter -eq 'Safe' -and $o.Risk -ne 'Safe') { return $false }
    if ($script:RiskFilter -eq 'SafeMod' -and $o.Risk -eq 'Risky') { return $false }
    if ($script:RiskFilter -eq 'Risky' -and $o.Risk -ne 'Risky') { return $false }
    (-not $q) -or ($o.Name -like "*$q*") -or ($o.Category -like "*$q*") -or ($o.Desc -like "*$q*")
}
$script:ui_SearchBox.Add_TextChanged({ $script:SearchText = $script:ui_SearchBox.Text; $script:View.Refresh() })
$script:ui_TweakGrid.Add_SelectionChanged({
    $s = $script:ui_TweakGrid.SelectedItem
    if ($s) { $script:ui_DescText.Text = "[$($s.Risk)]  $($s.Desc)$(if($s.Reboot){'  (reboot needed)'})$(if($s.NoLaptop){'  (skipped in laptop mode)'})" }
})

# --- navigation
function Show-Page([string]$p) {
    $script:ui_PageTweaks.Visibility = 'Collapsed'; $script:ui_PageGames.Visibility = 'Collapsed'; $script:ui_PageInfo.Visibility = 'Collapsed'
    foreach ($b in $script:ui_NavTweaks, $script:ui_NavGames, $script:ui_NavInfo) { $b.Background = '#23263A' }
    switch ($p) {
        'T' { $script:ui_PageTweaks.Visibility = 'Visible'; $script:ui_NavTweaks.Background = '#8B6CFF' }
        'G' { $script:ui_PageGames.Visibility  = 'Visible'; $script:ui_NavGames.Background  = '#8B6CFF' }
        'I' { $script:ui_PageInfo.Visibility   = 'Visible'; $script:ui_NavInfo.Background   = '#8B6CFF' }
    }
}
$script:ui_NavTweaks.Add_Click({ Show-Page 'T' })
$script:ui_NavGames.Add_Click({ Show-Page 'G' })
$script:ui_NavInfo.Add_Click({ Show-Page 'I' })

# --- presets
$script:ui_BtnHigh.Add_Click({ Select-Preset 1; Log "High-End preset selected: $(@($script:Tweaks | Where-Object Selected).Count) tweaks. Review, then press APPLY SELECTED." })
$script:ui_BtnMid.Add_Click({  Select-Preset 2; Log "Mid-Range preset selected: $(@($script:Tweaks | Where-Object Selected).Count) tweaks. Review, then press APPLY SELECTED." })
$script:ui_BtnLow.Add_Click({  Select-Preset 3; Log "Low-End preset selected: $(@($script:Tweaks | Where-Object Selected).Count) tweaks. Review, then press APPLY SELECTED." })
$script:ui_BtnMenace.Add_Click({
    $warn = "MENACE MODE applies EVERY tweak, including the RISKY ones:`n`n" +
            " - Memory Integrity / VBS off`n - Spectre/Meltdown mitigations off`n - Defender real-time protection off`n" +
            " - SmartScreen off`n - Xbox + Print Spooler services off`n - Hypervisor off (breaks WSL2/Docker/VMs)`n" +
            " - Vendor control suites stopped on desktops (Armoury Crate / MSI Center / Synapse: fan, RGB, macros)`n`n" +
            "A restore point is created first and every change can be undone with REVERT EVERYTHING (reboot after).`n`nContinue?"
    $r = [System.Windows.MessageBox]::Show($warn, 'MENACE MODE', 'YesNo', 'Warning')
    if ($r -eq 'Yes') {
        Select-Preset 4
        $list = @($script:Tweaks | Where-Object Selected)
        Run-Apply $list
    }
})
$script:ui_BtnNone.Add_Click({ foreach ($t in $script:Tweaks) { $t.Selected = $false } })

# --- apply / revert
$script:ui_BtnApply.Add_Click({
    $list = @($script:Tweaks | Where-Object Selected)
    $risky = @($list | Where-Object { $_.Risk -eq 'Risky' })
    if ($risky.Count -gt 0) {
        $r = [System.Windows.MessageBox]::Show("$($risky.Count) selected tweak(s) are marked RISKY (security/compat trade-offs). Apply anyway?", 'Strix Tweaks', 'YesNo', 'Warning')
        if ($r -ne 'Yes') { return }
    }
    Run-Apply $list
})
$script:ui_BtnRevert.Add_Click({ Run-Revert @($script:Tweaks | Where-Object { $_.Selected -and (Test-Applied $_.Id) }) })
$script:ui_BtnRevertAll.Add_Click({
    $r = [System.Windows.MessageBox]::Show('Revert EVERY tweak Strix has applied and restore your original values?', 'Strix Tweaks', 'YesNo', 'Question')
    if ($r -eq 'Yes') {
        Run-Revert @($script:Tweaks | Where-Object { Test-Applied $_.Id })
        Get-ChildItem $script:UndoDir -Filter 'game.*.json' -ErrorAction SilentlyContinue | ForEach-Object { Restore-Records ($_.BaseName) }
    }
})

# --- games
foreach ($g in $script:Games) { [void]$script:ui_GameList.Items.Add($g.Name) }
function Get-SelectedGame { $script:Games | Where-Object { $_.Name -eq $script:ui_GameList.SelectedItem } | Select-Object -First 1 }
$script:ui_GameList.Add_SelectionChanged({
    $g = Get-SelectedGame
    if (-not $g) { return }
    $ac = if ($g.AC) { 'YES - Strix will NOT touch CPU priority for this game (only GPU preference + fullscreen flag).' } else { 'No' }
    $script:ui_GameText.Text = "$($g.Name)`r`nProcess: $($g.Exe)`r`nAnti-cheat / kernel protected: $ac`r`nLaunch options: $($g.Launch)`r`n`r`n" +
        "HIGH-END`r`n$($g.High)`r`n`r`nMID-RANGE`r`n$($g.Mid)`r`n`r`nLOW-END`r`n$($g.Low)"
})
$script:ui_GameList.SelectedIndex = 0
$script:ui_BtnGameApply.Add_Click({
    $g = Get-SelectedGame
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = 'Game executable (*.exe)|*.exe'
    $dlg.Title  = if ($g -and $g.Exe) { "Locate $($g.Exe)" } else { 'Locate the game .exe' }
    if ($dlg.ShowDialog() -eq 'OK') {
        $ac = if ($g) { [bool]$g.AC } else { $false }
        $exe = [IO.Path]::GetFileName($dlg.FileName)
        if ($exe -match 'VALORANT|FortniteClient|r5apex|cod\.exe|GTA5|RocketLeague|League of Legends|RainbowSix|PUBG|TslGame|Marvel-Win64|eldenring|RobloxPlayer') { $ac = $true }
        New-RestorePoint
        Apply-GameProfile $dlg.FileName $ac ([bool]$script:ui_ChkCfg.IsChecked)
    }
})
$script:ui_BtnGameRevert.Add_Click({
    $files = @(Get-ChildItem $script:UndoDir -Filter 'game.*.json' -ErrorAction SilentlyContinue)
    foreach ($f in $files) { Log "- Reverting game profile $($f.BaseName)"; Restore-Records $f.BaseName }
    if ($files.Count -eq 0) { Log 'No game profiles applied.' }
})

# --- info page
$script:ui_InfoText.Text = @"
STRIX TWEAKS 1.6  -  how it works

PRESETS (they only TICK the boxes - you review, then press APPLY):
  High-End   : the safe baseline. Latency, scheduler, GPU/timer, privacy and background cleanup. Keeps visuals and security.
  Mid-Range  : High-End + service cleanup, UI trimming, DNS/TCP and storage tidy-ups.
  Low-End    : Mid + animations off, power plan, aggressive services, kernel timer, memory, driver-level power tweaks.
  MENACE     : every tweak, including the RISKY security/compat ones. Asks you to confirm first.
  The 'In preset' column shows the lowest preset a tweak belongs to.

UNDO:
  Before each tweak Strix saves the ORIGINAL registry value / service state / task state / power plan to
  $($script:UndoDir)
  'Revert selected' and 'REVERT EVERYTHING' restore those exact values. A Windows restore point is also created first.
  'View applied changes' lists every value Strix changed: original vs current. Reboot after reverting kernel/graphics tweaks.

LAPTOP MODE: skips tweaks that fight battery life or thermals (power plan, throttling, timers, hibernation, NIC power saving, GPU lock, vendor suites).

OPTIMUS / MUX SAFETY: on laptops with hybrid graphics (iGPU + dGPU), display-path tweaks like Disable MPO can cause a black screen when the
  laptop switches GPUs. While the checkbox is ticked those tweaks are skipped. If the screen goes black anyway: Win+Ctrl+Shift+B,
  or boot to Safe Mode and run REVERT EVERYTHING.

LATENCY CHECK (Tools tab): reads the real Windows timer resolution (NtQueryTimerResolution), measures how precisely Sleep(1) wakes up,
  and samples DPC time / DPC rate / interrupt rate for 3 seconds. The first run is saved as BEFORE; run it again after your tweaks
  (and a reboot) to see the change. It is a quick indicator, not LatencyMon - Windows 11 also treats timer requests per-process,
  so the 'Force 0.5 ms timer' button only holds the request while Strix is open.

UNATTENDED MODE (for Winget / AME / post-install scripts) - no GUI, run from an elevated prompt:
  powershell -ExecutionPolicy Bypass -File StrixTweaks.ps1 -Preset Mid
  powershell -ExecutionPolicy Bypass -File StrixTweaks.ps1 -Preset Low -Laptop -NoRestorePoint
  powershell -ExecutionPolicy Bypass -File StrixTweaks.ps1 -Preset Menace -AcceptRisk
  powershell -ExecutionPolicy Bypass -File StrixTweaks.ps1 -ProfilePath my-setup.strix
  powershell -ExecutionPolicy Bypass -File StrixTweaks.ps1 -Revert        (or -List to print every tweak)
  Add -AllowHybridRisk to bypass the Optimus/MUX safety. Exit codes: 0 OK, 3010 OK + reboot needed, 2 refused, 5 not elevated.
  Per-user (HKCU) tweaks apply to the account that runs the script, so do not run it as SYSTEM for a user's PC.

WHAT REALLY MOVES FPS (be honest with yourself):
  1. Update your GPU driver (clean install via DDU if you have issues), enable XMP/EXPO in BIOS, enable Resizable BAR.
  2. Game settings: shadows, volumetrics and ambient occlusion cost the most; upscalers (DLSS/FSR) give the biggest jump.
  3. Close overlays/launchers/browsers. Keep the game on an SSD. Keep the PC cool (thermal throttling beats any tweak).
  4. The tweaks here mostly reduce stutter, input latency and background load; the Risky ones (VBS off, mitigations off,
     hypervisor off) can add real FPS in CPU-bound games but have genuine security trade-offs.

DELIBERATELY NOT INCLUDED: turning off UAC, the firewall or Windows Update entirely - they cost security/stability and give no FPS.

Anti-cheat note: Vanguard, EAC, BattlEye and Ricochet games get only GPU preference + fullscreen flag from Strix (no IFEO priority key,
no Control Flow Guard change). Some anti-cheats dislike disabled VBS/hypervisor/test-signing settings: check your game's requirements
before using MENACE MODE.
Log file: $($script:LogFile)
"@
$script:ui_BtnRP.Add_Click({ $script:RPDone = $false; New-RestorePoint })
$script:ui_BtnTemp.Add_Click({
    Log 'Cleaning temp files...'; Pump
    Get-ChildItem $env:TEMP, "$env:windir\Temp" -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    Log 'Temp files cleaned.'
})
$script:ui_BtnFolder.Add_Click({ Start-Process explorer.exe $script:StateDir })

Log "Strix Tweaks 1.6 ready. Suggested preset for this machine: $($script:Suggest). $($script:Tweaks.Count) tweaks loaded."
if ($script:Build -lt 22000) { Log 'WARNING: not Windows 11 - some tweaks may not apply.' }

# ------------------------------------------------------------------ v1.6: filters, hybrid guard, status bar, tools, features
$script:CatFilter = ''
$script:RiskFilter = ''

[void]$script:ui_CatBox.Items.Add('All categories')
foreach ($c in ($script:Tweaks | ForEach-Object { $_.Category } | Select-Object -Unique | Sort-Object)) { [void]$script:ui_CatBox.Items.Add($c) }
$script:ui_CatBox.SelectedIndex = 0
$script:ui_CatBox.Add_SelectionChanged({
    $s = [string]$script:ui_CatBox.SelectedItem
    $script:CatFilter = if ($s -eq 'All categories') { '' } else { $s }
    $script:View.Refresh()
})

foreach ($r in 'All risks', 'Safe only', 'Moderate & Safe', 'Risky only') { [void]$script:ui_RiskBox.Items.Add($r) }
$script:ui_RiskBox.SelectedIndex = 0
$script:ui_RiskBox.Add_SelectionChanged({
    $script:RiskFilter = switch ([string]$script:ui_RiskBox.SelectedItem) {
        'Safe only'       { 'Safe' }
        'Moderate & Safe' { 'SafeMod' }
        'Risky only'      { 'Risky' }
        default           { '' }
    }
    $script:View.Refresh()
})

# --- Optimus / MUX safety toggle
$script:ui_ChkHybrid.IsChecked = $script:HybridSafe
if (-not $script:Hybrid) {
    $script:ui_ChkHybrid.IsChecked = $true
    $script:ui_ChkHybrid.IsEnabled = $false
    $script:ui_ChkHybrid.Content = 'Optimus/MUX safety (no hybrid graphics detected - not needed)'
}
$script:ui_ChkHybrid.Add_Click({
    $script:HybridSafe = [bool]$script:ui_ChkHybrid.IsChecked
    if (-not $script:HybridSafe) {
        $msg = "You are turning OFF the Optimus/MUX safety on a hybrid-graphics laptop.`n`n" +
               "Display-path tweaks like Disable MPO can cause a BLACK SCREEN when the laptop switches between the integrated and the dedicated GPU (Optimus / Advanced Optimus / MUX).`n`n" +
               "If the screen goes black: press Win+Ctrl+Shift+B, or boot to Safe Mode and run REVERT EVERYTHING in Strix.`n`nKeep the safety OFF?"
        $r = [System.Windows.MessageBox]::Show($msg, 'Optimus / MUX safety', 'YesNo', 'Warning')
        if ($r -ne 'Yes') { $script:HybridSafe = $true; $script:ui_ChkHybrid.IsChecked = $true }
    }
    Update-Status
})

$script:ui_BtnAuto.Add_Click({
    $tier = switch ($script:Suggest) { 'High-End' { 1 } 'Mid-Range' { 2 } default { 3 } }
    Select-Preset $tier
    Log "Auto preset ($($script:Suggest)) selected: $(@($script:Tweaks | Where-Object Selected).Count) tweaks. Review, then press APPLY SELECTED."
})

# --- live status bar
$script:BC = New-Object System.Windows.Media.BrushConverter
function Get-Brush([string]$hex) { return $script:BC.ConvertFromString($hex) }
$script:StTick = 0
$script:PlanName = '...'
$script:VbsState = '...'
$script:HagsState = '...'

function Get-VbsState {
    try {
        $dg = Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard -ErrorAction Stop
        $svc = @($dg.SecurityServicesRunning)
        if ([int]$dg.VirtualizationBasedSecurityStatus -eq 2) {
            if ($svc -contains 2) { return 'ON (Memory Integrity active)' }
            return 'ON'
        }
        return 'OFF'
    } catch { return 'unknown' }
}
function Get-PlanName {
    try {
        $o = powercfg /getactivescheme 2>&1 | Out-String
        if ($o -match '\(([^)]+)\)') { return $Matches[1] }
    } catch {}
    return 'unknown'
}
function Get-HagsState {
    $v = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name HwSchMode -ErrorAction SilentlyContinue).HwSchMode
    if ($v -eq 2) { return 'ON' } elseif ($v -eq 1) { return 'OFF' } else { return 'default' }
}
function Update-Status {
    $script:StTick++
    if ($script:StTick -eq 1 -or ($script:StTick % 3) -eq 0)  { $script:PlanName = Get-PlanName; $script:HagsState = Get-HagsState }
    if ($script:StTick -eq 1 -or ($script:StTick % 15) -eq 0) { $script:VbsState = Get-VbsState }

    $t = [StrixTimer]::CurrentMs()
    $script:ui_StTimer.Text = ('TIMER {0:N3} ms' -f $t)
    $script:ui_StTimer.Foreground = Get-Brush $(if ($t -le 1.1) { '#5CE08A' } elseif ($t -le 8) { '#FFC857' } else { '#FF5C5C' })

    $script:ui_StVbs.Text = "VBS/HVCI $($script:VbsState)"
    $script:ui_StVbs.Foreground = Get-Brush $(if ($script:VbsState -eq 'OFF') { '#5CE08A' } elseif ($script:VbsState -eq 'unknown') { '#9AA0B8' } else { '#FFC857' })

    $script:ui_StPlan.Text = "PLAN $($script:PlanName)"
    $script:ui_StPlan.Foreground = Get-Brush $(if ($script:PlanName -match 'Strix|Ultimate|High performance') { '#5CE08A' } else { '#FFC857' })

    $guard = if ($script:Hybrid) { if ($script:HybridSafe) { 'hybrid GPU, guard ON' } else { 'hybrid GPU, guard OFF' } } else { 'single GPU path' }
    $script:ui_StGpu.Text = "HAGS $($script:HagsState) | $guard"
    $script:ui_StGpu.Foreground = Get-Brush $(if ($script:Hybrid -and -not $script:HybridSafe) { '#FF5C5C' } else { '#9AA0B8' })

    $n = @(Get-ChildItem -LiteralPath $script:UndoDir -Filter '*.json' -ErrorAction SilentlyContinue).Count
    $script:ui_StApplied.Text = "STRIX: $n change set(s) applied"
    $script:ui_StApplied.Foreground = Get-Brush $(if ($n -gt 0) { '#8B6CFF' } else { '#9AA0B8' })
}
$script:StatusTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:StatusTimer.Interval = [TimeSpan]::FromSeconds(2)
$script:StatusTimer.Add_Tick({ try { Update-Status } catch {} })
try { Update-Status } catch {}
$script:StatusTimer.Start()

# --- maintenance tools
function Clear-Dirs([string[]]$paths, [string]$label) {
    $freed = 0L
    foreach ($p in $paths) {
        if (Test-Path -LiteralPath $p) {
            $sz = (Get-ChildItem -LiteralPath $p -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
            Get-ChildItem -LiteralPath $p -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
            $freed += [long]$sz
            Log "  cleared $p"
        }
    }
    Log ('{0}: about {1:N1} MB freed. Games rebuild shaders on next launch, so expect one slightly stuttery first run.' -f $label, ($freed / 1MB))
}
$script:ui_BtnShaderDx.Add_Click({
    Log 'Purging DirectX shader cache...'; Pump
    Clear-Dirs @("$env:LOCALAPPDATA\D3DSCache") 'DirectX cache'
})
$script:ui_BtnShaderGpu.Add_Click({
    Log 'Purging NVIDIA / AMD shader caches...'; Pump
    Clear-Dirs @("$env:LOCALAPPDATA\NVIDIA\DXCache", "$env:LOCALAPPDATA\NVIDIA\GLCache", "$env:ProgramData\NVIDIA Corporation\NV_Cache",
                 "$env:LOCALAPPDATA\AMD\DxCache", "$env:LOCALAPPDATA\AMD\GLCache", "$env:LOCALAPPDATA\AMD\VkCache") 'GPU vendor cache'
})
$script:ui_BtnNet.Add_Click({
    $r = [System.Windows.MessageBox]::Show("Reset the Windows network stack (Winsock) and flush DNS?`n`nFixes broken sockets / odd latency. A reboot is needed afterwards, and some VPN or security software may need to reconnect.", 'Reset network stack', 'YesNo', 'Question')
    if ($r -eq 'Yes') {
        netsh winsock reset | Out-Null
        ipconfig /flushdns | Out-Null
        Log 'Winsock reset + DNS flushed. REBOOT to finish the reset.'
    }
})

function Free-Ram {
    $script:Window.IsEnabled = $false
    try {
        Log 'Freeing RAM (empty working sets + purge standby list)...'
        Pump
        [void][StrixMem]::Priv()
        $before = (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory
        [void][StrixMem]::Cmd(2)
        [void][StrixMem]::Cmd(3)
        [void][StrixMem]::Cmd(4)
        Start-Sleep -Milliseconds 800
        $after = (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory
        Log ('RAM: {0:N0} MB free now (was {1:N0} MB). Apps may reload some pages briefly.' -f ($after / 1024), ($before / 1024))
    } catch { Log "RAM cleanup failed: $($_.Exception.Message)" }
    finally { $script:Window.IsEnabled = $true }
}
$script:ui_BtnRam.Add_Click({ Free-Ram })
$script:ui_BtnTrim.Add_Click({
    if (-not $script:SysIsSSD) { Log 'Windows drive is an HDD - TRIM not applicable.'; return }
    Log 'Running SSD re-TRIM on the system drive...'
    Pump
    try { Optimize-Volume -DriveLetter $env:SystemDrive[0] -ReTrim -ErrorAction Stop; Log 'TRIM finished.' } catch { Log "TRIM failed: $($_.Exception.Message)" }
})
$script:ui_BtnDns.Add_Click({ ipconfig /flushdns | Out-Null; Log 'DNS cache flushed.' })
$script:ui_BtnStartup.Add_Click({ Start-Process 'ms-settings:startupapps' })
$script:ui_BtnGfx.Add_Click({ Start-Process 'ms-settings:display-advancedgraphics' })
$script:ui_BtnSec.Add_Click({ Start-Process 'windowsdefender:' })

# --- latency check (timer resolution, Sleep(1) precision, DPC/interrupt rates)
$script:BaseFile = Join-Path $script:StateDir 'latency-baseline.json'

function Measure-Latency {
    Log 'Latency check running (about 4 seconds)...'
    Pump
    $s = [StrixTimer]::SleepTest(100)
    $dpc = @(); $dq = @(); $it = @()
    for ($i = 0; $i -lt 4; $i++) {
        $p = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -ErrorAction SilentlyContinue
        if ($p -and $i -gt 0) { $dpc += [double]$p.PercentDPCTime; $dq += [double]$p.DPCsQueuedPersec; $it += [double]$p.InterruptsPersec }
        Start-Sleep -Milliseconds 800
        Pump
    }
    $avg = { param($a) if ($a.Count -gt 0) { ($a | Measure-Object -Average).Average } else { 0 } }
    return [pscustomobject]@{
        Stamp    = (Get-Date).ToString('yyyy-MM-dd HH:mm')
        TimerMs  = [math]::Round([StrixTimer]::CurrentMs(), 3)
        SleepAvg = [math]::Round($s[0], 3)
        SleepMax = [math]::Round($s[1], 3)
        DpcPct   = [math]::Round((& $avg $dpc), 3)
        DpcRate  = [math]::Round((& $avg $dq), 1)
        IntRate  = [math]::Round((& $avg $it), 1)
    }
}

function Format-Latency($now, $base) {
    $rows = @(
        @('Timer resolution (ms)', 'TimerMs',  'N3'),
        @('Sleep(1) average (ms)', 'SleepAvg', 'N3'),
        @('Sleep(1) worst (ms)',   'SleepMax', 'N3'),
        @('DPC time (% of CPU)',   'DpcPct',   'N3'),
        @('DPCs queued / sec',     'DpcRate',  'N0'),
        @('Interrupts / sec',      'IntRate',  'N0')
    )
    $sb = New-Object System.Text.StringBuilder
    $bStamp = if ($base) { $base.Stamp } else { '-' }
    [void]$sb.AppendLine(('BEFORE: {0}    NOW: {1}' -f $bStamp, $now.Stamp))
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine(('{0,-24}{1,12}{2,12}{3,11}' -f '', 'BEFORE', 'NOW', 'CHANGE'))
    foreach ($r in $rows) {
        $n = [double]$now.($r[1])
        $bs = '-'; $ch = ''
        if ($base) {
            $b = [double]$base.($r[1])
            $bs = $b.ToString($r[2])
            if ($b -ne 0) { $ch = '{0:+0.0;-0.0;0.0}%' -f (($n - $b) / $b * 100) }
        }
        [void]$sb.AppendLine(('{0,-24}{1,12}{2,12}{3,11}' -f $r[0], $bs, $n.ToString($r[2]), $ch))
    }
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine('Lower is better on every line. 15.625 ms = Windows default tick; 1.000 / 0.500 ms = tuned.')
    if ($script:TimerForced) { [void]$sb.AppendLine('Note: Strix is currently holding a 0.5 ms timer request, which also tightens the Sleep(1) test.') }
    [void]$sb.AppendLine('Sleep(1) shows how precisely this process can be scheduled; DPC/interrupt numbers are a 3-second sample of the whole PC.')
    [void]$sb.AppendLine('It is an indicator, not a replacement for LatencyMon/xperf. For a fair comparison: same apps open, same idle state, reboot after tweaks.')
    return $sb.ToString()
}

function Run-LatencyCheck([bool]$setBase) {
    $script:Window.IsEnabled = $false
    try {
        $now = Measure-Latency
        $base = $null
        $note = ''
        if ($setBase -or -not (Test-Path -LiteralPath $script:BaseFile)) {
            $now | ConvertTo-Json | Set-Content -LiteralPath $script:BaseFile -Encoding UTF8
            $base = $now
            $note = "Saved as your BEFORE baseline. Apply your tweaks (reboot if asked), then press 'Run latency check' again to compare.`r`n`r`n"
        } else {
            $base = Get-Content -LiteralPath $script:BaseFile -Raw | ConvertFrom-Json
        }
        $script:ui_LatText.Text = $note + (Format-Latency $now $base)
        Update-Status
    } catch { Log "Latency check failed: $($_.Exception.Message)" }
    finally { $script:Window.IsEnabled = $true }
}
$script:ui_LatText.Text = "Press 'Run latency check'.`r`nThe first run is saved as your BEFORE baseline; run it again after applying tweaks (and rebooting) to see the difference.`r`n`r`nMeasures: system timer resolution (NtQueryTimerResolution), Sleep(1) precision, DPC time, DPC rate and interrupt rate."
$script:ui_BtnLat.Add_Click({ Run-LatencyCheck $false })
$script:ui_BtnLatBase.Add_Click({ Run-LatencyCheck $true })
$script:ui_BtnLatReset.Add_Click({
    Remove-Item -LiteralPath $script:BaseFile -Force -ErrorAction SilentlyContinue
    $script:ui_LatText.Text = 'Baseline cleared. The next check will be saved as the new BEFORE.'
})

$script:TimerForced = $false
$script:ui_BtnForceTimer.Add_Click({
    if (-not $script:TimerForced) {
        $a = [StrixTimer]::Force($true)
        $script:TimerForced = $true
        $script:ui_BtnForceTimer.Content = 'Release 0.5 ms timer'
        Log ('Timer request active: {0:N3} ms (held while Strix is open).' -f $a)
    } else {
        [void][StrixTimer]::Force($false)
        $script:TimerForced = $false
        $script:ui_BtnForceTimer.Content = 'Force 0.5 ms timer (while Strix is open)'
        Log 'Timer request released.'
    }
    Update-Status
})
$script:Window.Add_Closed({
    if ($script:TimerForced) { [void][StrixTimer]::Force($false) }
    $script:StatusTimer.Stop()
})

# --- profiles (.strix)
$script:ui_BtnExport.Add_Click({
    $sel = @($script:Tweaks | Where-Object Selected | ForEach-Object { $_.Id })
    if ($sel.Count -eq 0) { Log 'Nothing selected to export. Tick some tweaks first.'; return }
    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    $dlg.Filter = 'Strix profile (*.strix)|*.strix|JSON (*.json)|*.json'
    $dlg.FileName = 'my-setup.strix'
    if ($dlg.ShowDialog() -eq 'OK') {
        $o = [ordered]@{
            app     = 'StrixTweaks'
            version = $script:Version
            created = (Get-Date).ToString('s')
            laptop  = [bool]$script:ui_ChkLaptop.IsChecked
            tweaks  = $sel
        }
        ($o | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $dlg.FileName -Encoding UTF8
        Log "Profile exported: $($dlg.FileName) ($($sel.Count) tweaks). Re-apply it any time with the Import button or: StrixTweaks.ps1 -ProfilePath `"$($dlg.FileName)`""
    }
})
$script:ui_BtnImport.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = 'Strix profile (*.strix;*.json)|*.strix;*.json'
    if ($dlg.ShowDialog() -eq 'OK') {
        $p = Read-StrixProfile $dlg.FileName
        if (-not $p) { return }
        $ids = @($p.tweaks)
        $miss = 0
        foreach ($t in $script:Tweaks) { $t.Selected = ($ids -contains $t.Id) }
        foreach ($id in $ids) { if (-not ($script:Tweaks | Where-Object { $_.Id -eq $id })) { $miss++ } }
        $script:ui_ChkLaptop.IsChecked = [bool]$p.laptop
        Log "Profile imported: $(@($script:Tweaks | Where-Object Selected).Count) tweaks ticked$(if ($miss) { " ($miss unknown id(s) ignored)" }). Review, then press APPLY SELECTED."
    }
})

# --- applied-changes viewer (original vs current)
function Format-Val($v) {
    if ($null -eq $v) { return '' }
    if ($v -is [array]) { return ($v -join ' ') }
    return [string]$v
}
function Show-ChangeViewer {
    $files = @(Get-ChildItem -LiteralPath $script:UndoDir -Filter '*.json' -ErrorAction SilentlyContinue)
    if ($files.Count -eq 0) {
        [void][System.Windows.MessageBox]::Show('Nothing applied yet. After you apply tweaks, this window lists every value Strix changed: the original and the current one.', 'Applied changes')
        return
    }
    $svcNow = @{}
    Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | ForEach-Object { $svcNow[$_.Name] = '{0} ({1})' -f $_.StartMode, $_.State }
    $rows = New-Object System.Collections.ArrayList
    foreach ($f in $files) {
        $id = $f.BaseName
        $tw = $script:Tweaks | Where-Object { $_.Id -eq $id } | Select-Object -First 1
        $name = if ($tw) { $tw.Name } elseif ($id -like 'game.*') { 'Game profile: ' + $id.Substring(5) } else { $id }
        $recs = @(Get-Content -LiteralPath $f.FullName -Raw | ConvertFrom-Json)
        foreach ($r in $recs) {
            switch ($r.t) {
                'reg' {
                    $orig = if ($r.existed) { '{0}  [{1}]' -f (Format-Val $r.value), $r.kind } else { '(did not exist)' }
                    $cur = '(missing)'
                    try {
                        $k = Get-Item -LiteralPath $r.path -ErrorAction Stop
                        if ($k.GetValueNames() -contains $r.name) { $cur = Format-Val $k.GetValue($r.name) }
                    } catch {}
                    [void]$rows.Add([pscustomobject]@{ Tweak = $name; Kind = 'Registry'; Target = ($r.path + ' \ ' + $r.name); Original = $orig; Current = $cur })
                }
                'svc' {
                    $orig = '{0}{1}' -f $r.mode, $(if ($r.running) { ' (was running)' } else { '' })
                    $cur = if ($svcNow.ContainsKey([string]$r.name)) { $svcNow[[string]$r.name] } else { '(not found)' }
                    [void]$rows.Add([pscustomobject]@{ Tweak = $name; Kind = 'Service'; Target = $r.name; Original = $orig; Current = $cur })
                }
                'task' {
                    $cur = '(not found)'
                    try { $cur = [string](Get-ScheduledTask -TaskPath $r.path -TaskName $r.name -ErrorAction Stop).State } catch {}
                    [void]$rows.Add([pscustomobject]@{ Tweak = $name; Kind = 'Scheduled task'; Target = ($r.path + $r.name); Original = 'Enabled'; Current = $cur })
                }
                'cmd' {
                    [void]$rows.Add([pscustomobject]@{ Tweak = $name; Kind = 'Command'; Target = 'runs on revert'; Original = $r.cmd; Current = '' })
                }
            }
        }
    }
    [xml]$dx = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Strix - applied changes (original vs current)" Width="1180" Height="640" Background="#0E0F14"
        WindowStartupLocation="CenterScreen" FontFamily="Segoe UI" FontSize="12.5">
  <Grid Margin="14">
    <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
    <TextBlock x:Name="DHead" Foreground="#9AA0B8" TextWrapping="Wrap" Margin="0,0,0,8"/>
    <DataGrid x:Name="DGrid" Grid.Row="1" AutoGenerateColumns="True" IsReadOnly="True" Background="#151720" RowBackground="#151720"
              AlternatingRowBackground="#191B26" Foreground="#E6E8F0" GridLinesVisibility="None" HeadersVisibility="Column" BorderThickness="0">
      <DataGrid.ColumnHeaderStyle>
        <Style TargetType="DataGridColumnHeader">
          <Setter Property="Background" Value="#1D2030"/><Setter Property="Foreground" Value="#9AA0B8"/>
          <Setter Property="Padding" Value="8,6"/><Setter Property="BorderThickness" Value="0"/>
        </Style>
      </DataGrid.ColumnHeaderStyle>
    </DataGrid>
    <StackPanel Grid.Row="2" Orientation="Horizontal" Margin="0,10,0,0">
      <Button x:Name="DCsv" Content="Export CSV" Padding="14,6" Margin="0,0,8,0"/>
      <Button x:Name="DClose" Content="Close" Padding="14,6"/>
    </StackPanel>
  </Grid>
</Window>
'@
    $w = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $dx))
    $script:dRows = $rows
    $script:dWin = $w
    $w.FindName('DHead').Text = "$($rows.Count) change(s) made by Strix. 'Original' is what Windows had before; 'Current' is the live value now. REVERT restores the Original column."
    $w.FindName('DGrid').ItemsSource = $rows
    $w.FindName('DClose').Add_Click({ $script:dWin.Close() })
    $w.FindName('DCsv').Add_Click({
        $dlg = New-Object System.Windows.Forms.SaveFileDialog
        $dlg.Filter = 'CSV (*.csv)|*.csv'; $dlg.FileName = 'strix-changes.csv'
        if ($dlg.ShowDialog() -eq 'OK') { $script:dRows | Export-Csv -LiteralPath $dlg.FileName -NoTypeInformation -Encoding UTF8; Log "Exported $($dlg.FileName)" }
    })
    $w.Owner = $script:Window
    [void]$w.ShowDialog()
}
$script:ui_BtnDiff.Add_Click({ Show-ChangeViewer })

# --- automatic game scanner
$script:GameNameRx = 'VALORANT|Riot|League of Legends|Counter-Strike|Fortnite|Apex|Call of Duty|Warzone|Warfare|Black Ops|Grand Theft|GTA|Cyberpunk|Overwatch|Rocket ?League|Rainbow|PUBG|BATTLEGROUNDS|Marvel|dota|Red Dead|Baldur|Roblox|ELDEN'

function Find-InstalledGames {
    $map = @{}
    foreach ($g in $script:Games) { if ($g.Exe -and $g.Exe -ne 'javaw.exe') { $map[$g.Exe.ToLower()] = $g } }
    $alias = @{ 'r5apex.exe' = 'Apex*'; 'rainbowsix.exe' = 'Rainbow*'; 'bg3.exe' = 'Baldur*' }
    foreach ($k in $alias.Keys) {
        $gg = $script:Games | Where-Object { $_.Name -like $alias[$k] } | Select-Object -First 1
        if ($gg) { $map[$k] = $gg }
    }

    $libs = New-Object System.Collections.Generic.List[string]
    $direct = New-Object System.Collections.Generic.List[string]

    $drives = @([IO.DriveInfo]::GetDrives() | Where-Object { $_.DriveType -eq 'Fixed' -and $_.IsReady } | ForEach-Object { $_.Name.TrimEnd('\') })
    foreach ($d in $drives) {
        foreach ($rel in 'SteamLibrary\steamapps\common', 'Steam\steamapps\common', 'Program Files (x86)\Steam\steamapps\common',
                         'Program Files\Epic Games', 'Epic Games', 'Riot Games', 'Games', 'XboxGames', 'Program Files\Rockstar Games') {
            $libs.Add("$d\$rel")
        }
        foreach ($rel in 'Program Files (x86)\Overwatch', 'Program Files\Overwatch') { $direct.Add("$d\$rel") }
    }

    # Steam: registry path + libraryfolders.vdf
    $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
    if ($steam) {
        $steam = $steam -replace '/', '\'
        $libs.Add("$steam\steamapps\common")
        $vdf = "$steam\steamapps\libraryfolders.vdf"
        if (Test-Path -LiteralPath $vdf) {
            foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"([^"]+)"')) {
                $libs.Add(($m.Groups[1].Value -replace '\\\\', '\') + '\steamapps\common')
            }
        }
    }

    # Epic: install manifests
    $man = "$env:ProgramData\Epic\EpicGamesLauncher\Data\Manifests"
    if (Test-Path -LiteralPath $man) {
        Get-ChildItem -LiteralPath $man -Filter '*.item' -ErrorAction SilentlyContinue | ForEach-Object {
            try { $j = Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json; if ($j.InstallLocation) { $direct.Add([string]$j.InstallLocation) } } catch {}
        }
    }

    # Uninstall keys (only entries that look like known games)
    foreach ($k in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall') {
        Get-ChildItem $k -ErrorAction SilentlyContinue | ForEach-Object {
            $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
            $loc = [string]$p.InstallLocation
            if ($loc -and (($p.DisplayName -match $script:GameNameRx) -or ($loc -match $script:GameNameRx))) { $direct.Add($loc.TrimEnd('\')) }
        }
    }
    if (Test-Path "$env:LOCALAPPDATA\Roblox\Versions") { $direct.Add("$env:LOCALAPPDATA\Roblox\Versions") }

    foreach ($lib in ($libs | Select-Object -Unique)) {
        if (Test-Path -LiteralPath $lib) {
            Get-ChildItem -LiteralPath $lib -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $script:GameNameRx } | ForEach-Object { $direct.Add($_.FullName) }
        }
    }

    $found = New-Object System.Collections.Generic.List[object]
    $seen = @{}
    $names = @($map.Keys)
    foreach ($root in ($direct | Select-Object -Unique)) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        Pump
        Get-ChildItem -LiteralPath $root -Recurse -Depth 7 -File -Include $names -ErrorAction SilentlyContinue | ForEach-Object {
            $key = $_.FullName.ToLower()
            if (-not $seen.ContainsKey($key)) {
                $seen[$key] = 1
                $found.Add([pscustomobject]@{ Game = $map[$_.Name.ToLower()]; Path = $_.FullName })
            }
        }
    }
    return $found.ToArray()
}

$script:ui_BtnGameScan.Add_Click({
    $script:Window.IsEnabled = $false
    $found = @()
    try {
        Log 'Scanning for installed games (Steam, Epic, Riot, uninstall list, common folders)...'
        Pump
        $found = @(Find-InstalledGames)
    } catch { Log "Scan failed: $($_.Exception.Message)" }
    finally { $script:Window.IsEnabled = $true }
    if ($found.Count -eq 0) {
        Log 'No supported games found. Use "Locate game .exe + apply profile" for anything the scan misses.'
        [void][System.Windows.MessageBox]::Show('No supported games were found. Use "Locate game .exe" to add one manually.', 'Game scan')
        return
    }
    $txt = ($found | ForEach-Object { '{0}  ->  {1}{2}' -f $_.Game.Name, $_.Path, $(if ($_.Game.AC) { '   [anti-cheat: GPU preference + fullscreen flag only]' } else { '' }) }) -join "`r`n"
    $script:ui_GameText.Text = "DETECTED GAMES ($($found.Count))`r`n`r`n$txt"
    Log "Found $($found.Count) game executable(s)."
    $r = [System.Windows.MessageBox]::Show("Found $($found.Count) game executable(s). Apply the Strix game profile (high-performance GPU, fullscreen-optimization flag, CPU priority for non-anti-cheat games) to all of them?`n`nEach is reversible with 'Revert all game profiles'.", 'Game scan', 'YesNo', 'Question')
    if ($r -eq 'Yes') {
        New-RestorePoint
        foreach ($f in $found) { Apply-GameProfile $f.Path ([bool]$f.Game.AC) $false }
    }
})

# --- core-affinity launcher
function Get-AffinityMask([int]$mode, [int]$n) {
    $cpus = [Math]::Min([Environment]::ProcessorCount, 64)
    [uint64]$m = 0
    switch ($mode) {
        0 { for ($i = 0; $i -lt $cpus; $i += 2) { $m = $m -bor ([uint64]1 -shl $i) } }
        1 { $c = [Math]::Max(1, [Math]::Min($n, $cpus)); for ($i = 0; $i -lt $c; $i++) { $m = $m -bor ([uint64]1 -shl $i) } }
        2 { for ($i = 1; $i -lt $cpus; $i++) { $m = $m -bor ([uint64]1 -shl $i) } }
        default { for ($i = 0; $i -lt $cpus; $i++) { $m = $m -bor ([uint64]1 -shl $i) } }
    }
    return $m
}

function Show-AffinityDialog {
    [xml]$ax = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Strix - core-affinity launcher" Width="600" Height="470" Background="#0E0F14" ResizeMode="NoResize"
        WindowStartupLocation="CenterScreen" FontFamily="Segoe UI" FontSize="13">
  <StackPanel Margin="20">
    <TextBlock Text="CPU CORE-AFFINITY LAUNCHER" FontSize="18" FontWeight="Black" Foreground="#8B6CFF"/>
    <TextBlock TextWrapping="Wrap" Foreground="#9AA0B8" Margin="0,6,0,14"
               Text="Creates a Desktop shortcut (.bat) that starts the game pinned to the CPUs you choose. Nothing is changed system-wide; delete the .bat to undo. Not recommended for anti-cheat games: launching the .exe directly can bypass the launcher and some anti-cheats dislike affinity changes."/>
    <DockPanel Margin="0,0,0,10">
      <Button x:Name="ABrowse" DockPanel.Dock="Right" Content="Browse..." Margin="8,0,0,0" Padding="12,4"/>
      <TextBox x:Name="APath" Height="28" VerticalContentAlignment="Center"/>
    </DockPanel>
    <TextBlock Text="Pin the game to:" Foreground="#C9CEE0"/>
    <ComboBox x:Name="AMode" Margin="0,4,0,10" Height="28"/>
    <StackPanel Orientation="Horizontal">
      <TextBlock Text="N (only for 'first N logical CPUs'): " Foreground="#C9CEE0" VerticalAlignment="Center"/>
      <TextBox x:Name="ACount" Width="60" Height="26" VerticalContentAlignment="Center"/>
    </StackPanel>
    <TextBlock x:Name="AInfo" Foreground="#35E0FF" Margin="0,14,0,0" TextWrapping="Wrap" FontFamily="Consolas"/>
    <TextBlock Foreground="#9AA0B8" Margin="0,12,0,0" TextWrapping="Wrap"
               Text="Tips: Intel hybrid CPUs list P-core threads first, so 'first N' with N = 2 x P-cores keeps the game off E-cores. On dual-CCD Ryzen X3D chips the V-Cache CCD is normally CCD0, the first half of the logical CPUs."/>
    <Button x:Name="ACreate" Content="Create launcher on Desktop" Margin="0,16,0,0" Padding="14,8" HorizontalAlignment="Left"/>
  </StackPanel>
</Window>
'@
    $script:aw = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $ax))
    $script:aPath = $script:aw.FindName('APath')
    $script:aMode = $script:aw.FindName('AMode')
    $script:aCount = $script:aw.FindName('ACount')
    $script:aInfo = $script:aw.FindName('AInfo')
    foreach ($m in 'Physical cores only (skip hyper-threads / SMT siblings)', 'First N logical CPUs (P-cores / CCD0)', 'All CPUs except CPU 0 (leave one free for Windows)', 'Every CPU (no restriction)') { [void]$script:aMode.Items.Add($m) }
    $script:aMode.SelectedIndex = 0
    $script:aCount.Text = [string][Math]::Max(1, [int]([Environment]::ProcessorCount / 2))

    $script:aRefresh = {
        $n = 0; [void][int]::TryParse($script:aCount.Text, [ref]$n)
        $mk = Get-AffinityMask $script:aMode.SelectedIndex $n
        $ones = 0
        for ($i = 0; $i -lt 64; $i++) { if ((($mk -shr $i) -band 1) -eq 1) { $ones++ } }
        $script:aInfo.Text = ('Affinity mask: 0x{0}   ({1} of {2} logical CPUs)' -f $mk.ToString('X'), $ones, [Environment]::ProcessorCount)
    }
    $script:aMode.Add_SelectionChanged({ & $script:aRefresh })
    $script:aCount.Add_TextChanged({ & $script:aRefresh })
    & $script:aRefresh

    $script:aw.FindName('ABrowse').Add_Click({
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = 'Game executable (*.exe)|*.exe'
        if ($dlg.ShowDialog() -eq 'OK') { $script:aPath.Text = $dlg.FileName }
    })
    $script:aw.FindName('ACreate').Add_Click({
        $p = $script:aPath.Text.Trim('" ')
        if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { $script:aInfo.Text = 'Pick the game .exe first.'; return }
        $n = 0; [void][int]::TryParse($script:aCount.Text, [ref]$n)
        $hex = (Get-AffinityMask $script:aMode.SelectedIndex $n).ToString('X')
        $nm = [IO.Path]::GetFileNameWithoutExtension($p)
        $bat = Join-Path ([Environment]::GetFolderPath('Desktop')) "Strix - $nm (affinity).bat"
        $lines = @('@echo off', "rem Created by Strix Tweaks - starts the game pinned to CPU mask 0x$hex", ('cd /d "{0}"' -f (Split-Path -Parent $p)), ('start "" /affinity {0} "{1}"' -f $hex, $p))
        try {
            $enc = [Text.Encoding]::GetEncoding([System.Globalization.CultureInfo]::CurrentCulture.TextInfo.OEMCodePage)
            [IO.File]::WriteAllLines($bat, $lines, $enc)
            Log "Affinity launcher created: $bat (mask 0x$hex). Delete the .bat to undo."
            $script:aInfo.Text = "Created: $bat"
        } catch { $script:aInfo.Text = "Could not write launcher: $($_.Exception.Message)" }
    })
    $script:aw.Owner = $script:Window
    [void]$script:aw.ShowDialog()
}
$script:ui_BtnAffinity.Add_Click({ Show-AffinityDialog })

# animated accent line + main-window entrance
$script:Window.Opacity = 0
$script:Window.Add_Loaded({
    try {
        $ease = New-Object System.Windows.Media.Animation.CubicEase
        $ease.EasingMode = 'EaseOut'
        $fade = New-Object System.Windows.Media.Animation.DoubleAnimation(0, 1, [TimeSpan]::FromMilliseconds(750))
        $script:Window.BeginAnimation([System.Windows.UIElement]::OpacityProperty, $fade)
        $slide = New-Object System.Windows.Media.Animation.DoubleAnimation(26, 0, [TimeSpan]::FromMilliseconds(850))
        $slide.EasingFunction = $ease
        $script:ui_RootShift.BeginAnimation([System.Windows.Media.TranslateTransform]::YProperty, $slide)
        $flow = New-Object System.Windows.Media.Animation.DoubleAnimation(0, 0.5, [TimeSpan]::FromSeconds(2.2))
        $flow.RepeatBehavior = [System.Windows.Media.Animation.RepeatBehavior]::Forever
        $script:ui_AccentShift.BeginAnimation([System.Windows.Media.TranslateTransform]::XProperty, $flow)
    } catch { $script:Window.Opacity = 1 }
})

# ------------------------------------------------------------------ futuristic launch splash
$script:SplashOK = $true
try {
    [xml]$splashXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent" ResizeMode="NoResize"
        ShowInTaskbar="False" Topmost="True" Width="720" Height="460" WindowStartupLocation="CenterScreen">
  <Window.Triggers>
    <EventTrigger RoutedEvent="Window.Loaded">
      <BeginStoryboard>
        <Storyboard>
          <DoubleAnimation Storyboard.TargetName="RotOuter" Storyboard.TargetProperty="Angle" From="0" To="360" Duration="0:0:6" RepeatBehavior="Forever"/>
          <DoubleAnimation Storyboard.TargetName="RotMid" Storyboard.TargetProperty="Angle" From="360" To="0" Duration="0:0:3.5" RepeatBehavior="Forever"/>
          <DoubleAnimation Storyboard.TargetName="RotInner" Storyboard.TargetProperty="Angle" From="0" To="360" Duration="0:0:2" RepeatBehavior="Forever"/>
          <DoubleAnimation Storyboard.TargetName="ScanShift" Storyboard.TargetProperty="Y" From="0" To="390" Duration="0:0:1.7" RepeatBehavior="Forever"/>
          <DoubleAnimation Storyboard.TargetName="TitleScale" Storyboard.TargetProperty="ScaleX" From="0.5" To="1" Duration="0:0:0.9"/>
          <DoubleAnimation Storyboard.TargetName="TitleScale" Storyboard.TargetProperty="ScaleY" From="0.5" To="1" Duration="0:0:0.9"/>
          <DoubleAnimation Storyboard.TargetName="TitleBlock" Storyboard.TargetProperty="Opacity" From="0" To="1" Duration="0:0:0.9"/>
          <DoubleAnimation Storyboard.TargetName="SubBlock" Storyboard.TargetProperty="Opacity" From="0.3" To="1" Duration="0:0:0.6" AutoReverse="True" RepeatBehavior="Forever"/>
          <DoubleAnimation Storyboard.TargetName="BarScale" Storyboard.TargetProperty="ScaleX" From="0" To="1" Duration="0:0:4.2"/>
        </Storyboard>
      </BeginStoryboard>
    </EventTrigger>
  </Window.Triggers>
  <Grid Margin="30">
    <Border CornerRadius="22" BorderThickness="2" ClipToBounds="True">
      <Border.Effect><DropShadowEffect Color="#8B6CFF" BlurRadius="40" ShadowDepth="0" Opacity="0.65"/></Border.Effect>
      <Border.BorderBrush>
        <LinearGradientBrush StartPoint="0,0" EndPoint="1,1">
          <GradientStop Color="#8B6CFF" Offset="0"/><GradientStop Color="#35E0FF" Offset="0.5"/><GradientStop Color="#FF5C5C" Offset="1"/>
        </LinearGradientBrush>
      </Border.BorderBrush>
      <Border.Background>
        <RadialGradientBrush GradientOrigin="0.5,0.4" Center="0.5,0.4" RadiusX="0.85" RadiusY="0.85">
          <GradientStop Color="#1B1D3A" Offset="0"/><GradientStop Color="#07080D" Offset="1"/>
        </RadialGradientBrush>
      </Border.Background>
      <Grid>
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <Canvas Grid.RowSpan="3" IsHitTestVisible="False">
          <Rectangle Width="660" Height="2" Opacity="0.55">
            <Rectangle.Fill>
              <LinearGradientBrush StartPoint="0,0" EndPoint="1,0">
                <GradientStop Color="#0035E0FF" Offset="0"/><GradientStop Color="#35E0FF" Offset="0.5"/><GradientStop Color="#0035E0FF" Offset="1"/>
              </LinearGradientBrush>
            </Rectangle.Fill>
            <Rectangle.RenderTransform><TranslateTransform x:Name="ScanShift"/></Rectangle.RenderTransform>
          </Rectangle>
        </Canvas>
        <Grid Grid.Row="0" HorizontalAlignment="Center" VerticalAlignment="Center" Width="220" Height="220" Margin="0,16,0,0">
          <Ellipse Width="212" Height="212" Stroke="#8B6CFF" StrokeThickness="2" StrokeDashArray="10 6" RenderTransformOrigin="0.5,0.5">
            <Ellipse.RenderTransform><RotateTransform x:Name="RotOuter"/></Ellipse.RenderTransform>
          </Ellipse>
          <Ellipse Width="176" Height="176" Stroke="#FF5C5C" StrokeThickness="1.6" StrokeDashArray="22 10" RenderTransformOrigin="0.5,0.5">
            <Ellipse.RenderTransform><RotateTransform x:Name="RotMid"/></Ellipse.RenderTransform>
          </Ellipse>
          <Ellipse Width="142" Height="142" Stroke="#35E0FF" StrokeThickness="3" StrokeDashArray="1.5 5" RenderTransformOrigin="0.5,0.5">
            <Ellipse.RenderTransform><RotateTransform x:Name="RotInner"/></Ellipse.RenderTransform>
          </Ellipse>
          <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center">
            <TextBlock x:Name="TitleBlock" Text="STRIX" FontSize="36" FontWeight="Black" Foreground="White" HorizontalAlignment="Center" RenderTransformOrigin="0.5,0.5">
              <TextBlock.RenderTransform><ScaleTransform x:Name="TitleScale" ScaleX="0.5" ScaleY="0.5"/></TextBlock.RenderTransform>
              <TextBlock.Effect><DropShadowEffect Color="#8B6CFF" BlurRadius="22" ShadowDepth="0" Opacity="0.9"/></TextBlock.Effect>
            </TextBlock>
            <TextBlock x:Name="SubBlock" Text="TWEAKS 1.6" FontSize="12" FontWeight="Bold" Foreground="#35E0FF" HorizontalAlignment="Center"/>
          </StackPanel>
        </Grid>
        <TextBlock x:Name="StatusText" Grid.Row="1" Margin="40,6,40,6" Height="76" FontFamily="Consolas" FontSize="12.5" Foreground="#35E0FF" TextWrapping="NoWrap"/>
        <Grid Grid.Row="2" Margin="40,0,40,26">
          <Border Height="4" CornerRadius="2" Background="#1B1E33" VerticalAlignment="Center"/>
          <Border Height="4" CornerRadius="2" HorizontalAlignment="Stretch" VerticalAlignment="Center" RenderTransformOrigin="0,0.5">
            <Border.Background>
              <LinearGradientBrush StartPoint="0,0" EndPoint="1,0"><GradientStop Color="#8B6CFF" Offset="0"/><GradientStop Color="#35E0FF" Offset="0.6"/><GradientStop Color="#FF5C5C" Offset="1"/></LinearGradientBrush>
            </Border.Background>
            <Border.RenderTransform><ScaleTransform x:Name="BarScale" ScaleX="0"/></Border.RenderTransform>
          </Border>
          <TextBlock x:Name="PctText" Text="0%" Foreground="#9AA0B8" FontFamily="Consolas" FontSize="11" HorizontalAlignment="Right" VerticalAlignment="Top" Margin="0,-18,0,0"/>
        </Grid>
      </Grid>
    </Border>
  </Grid>
</Window>
'@
    $sr = New-Object System.Xml.XmlNodeReader $splashXaml
    $script:Splash = [Windows.Markup.XamlReader]::Load($sr)
    $script:SplashStatus = $script:Splash.FindName('StatusText')
    $script:SplashPct    = $script:Splash.FindName('PctText')

    $gpuShort = ($script:GpuName -split ',')[0].Trim()
    if ($gpuShort.Length -gt 44) { $gpuShort = $gpuShort.Substring(0, 44) }
    $cpuShort = $cpuInfo.Name.Trim()
    if ($cpuShort.Length -gt 44) { $cpuShort = $cpuShort.Substring(0, 44) }
    $script:BootLines = @(
        '> BOOTING STRIX CORE ........................ OK',
        "> CPU  : $cpuShort",
        "> GPU  : $gpuShort",
        "> RAM  : $($script:RamGB) GB    CORES : $($script:Cores)    $(if($script:IsLaptop){'MODE : LAPTOP'}else{'MODE : DESKTOP'})",
        "> LOADING $($script:Tweaks.Count) TWEAK MODULES ................ OK",
        '> ARMING UNDO ENGINE + RESTORE POINT ........ OK',
        "> SUGGESTED PRESET : $($script:Suggest.ToUpper())",
        "> TIMER : $([math]::Round([StrixTimer]::CurrentMs(), 3)) MS    DISPLAY GUARD : $(if ($script:Hybrid) { if ($script:HybridSafe) { 'OPTIMUS/MUX SAFETY ARMED' } else { 'BYPASSED' } } else { 'NO HYBRID GPU' })",
        '> ALL SYSTEMS NOMINAL ... LAUNCHING'
    )
    $script:BootIdx = 0; $script:TypePos = 0; $script:Pause = 0; $script:SplashDone = New-Object System.Collections.ArrayList
    $script:SplashClosing = $false

    function Close-Splash {
        if ($script:SplashClosing) { return }
        $script:SplashClosing = $true
        $script:SplashTimer.Stop()
        $fo = New-Object System.Windows.Media.Animation.DoubleAnimation(1, 0, [TimeSpan]::FromMilliseconds(420))
        $fo.Add_Completed({ $script:Splash.Close() })
        $script:Splash.BeginAnimation([System.Windows.UIElement]::OpacityProperty, $fo)
    }

    $script:SplashTimer = New-Object System.Windows.Threading.DispatcherTimer
    $script:SplashTimer.Interval = [TimeSpan]::FromMilliseconds(32)
    $script:SplashTimer.Add_Tick({
        if ($script:Pause -gt 0) { $script:Pause--; return }
        if ($script:BootIdx -ge $script:BootLines.Count) { Close-Splash; return }
        $line = $script:BootLines[$script:BootIdx]
        $script:TypePos += 4
        if ($script:TypePos -ge $line.Length) {
            [void]$script:SplashDone.Add($line)
            $script:BootIdx++; $script:TypePos = 0; $script:Pause = 5
            $cur = ''
            $script:SplashPct.Text = ('{0}%' -f [int](100 * $script:BootIdx / $script:BootLines.Count))
        } else {
            $cur = $line.Substring(0, $script:TypePos) + '_'
        }
        $shown = @($script:SplashDone | Select-Object -Last 4)
        if ($cur) { $shown = @($script:SplashDone | Select-Object -Last 3) + $cur }
        $script:SplashStatus.Text = ($shown -join "`n")
    })
    $script:Splash.Add_MouseLeftButtonDown({ Close-Splash })
    $script:SplashTimer.Start()
    [void]$script:Splash.ShowDialog()
} catch {
    Log "Splash skipped: $($_.Exception.Message)"
}

[void]$script:Window.ShowDialog()
